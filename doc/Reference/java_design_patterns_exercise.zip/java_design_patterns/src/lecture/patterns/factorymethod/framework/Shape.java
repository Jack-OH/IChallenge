package lecture.patterns.factorymethod.framework;

public abstract class Shape {
	public abstract void draw();
}
