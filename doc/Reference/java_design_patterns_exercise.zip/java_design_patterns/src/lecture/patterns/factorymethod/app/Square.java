package lecture.patterns.factorymethod.app;

import lecture.patterns.factorymethod.framework.*;

public class Square extends Shape{
	public void draw() {
		System.out.println("Draw Square");
	}
}
