package lecture.patterns.abstractfactory.framework.window;
import lecture.patterns.abstractfactory.framework.*;

public class WindowSquare extends Square{
	public void draw() {
		System.out.println("Draw Square for Window");
	}
}
