package lecture.patterns.abstractfactory.framework;

public abstract class Circle {
	public abstract void draw();
}
