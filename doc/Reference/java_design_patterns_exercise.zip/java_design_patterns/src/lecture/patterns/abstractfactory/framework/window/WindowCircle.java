package lecture.patterns.abstractfactory.framework.window;
import lecture.patterns.abstractfactory.framework.*;

public class WindowCircle extends Circle{
	public void draw() {
		System.out.println("Draw Circle for Window");
	}
}
