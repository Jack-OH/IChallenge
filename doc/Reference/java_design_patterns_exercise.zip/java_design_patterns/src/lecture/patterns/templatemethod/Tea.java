package lecture.patterns.templatemethod;

public class Tea {
    
	public void {
		System.out.println("Steeping the tea");
	}
	
	public void {
		System.out.println("Adding Lemon");
	}
}
