package lecture.patterns.templatemethod;

public class Coffee {
    
	public void {
		System.out.println("Dripping coffee through filter");
	}
	
	public void {
		System.out.println("Adding sugar and milk");
	}
	
}

    