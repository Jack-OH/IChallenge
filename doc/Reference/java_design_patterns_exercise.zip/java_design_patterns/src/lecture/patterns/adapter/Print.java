package lecture.patterns.adapter;

public interface Print {
    
    public abstract void printNormal();
    public abstract void printStrong();
}

    