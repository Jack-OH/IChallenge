#ifndef __HARDWARE_HOUSE_INFO_H
#define __HARDWARE_HOUSE_INFO_H
const char *hardware_id_str = "N-MAILBOX1";
const char schema[] PROGMEM = "\
class mailbox\
{\
    [read]\
    string mailbox; // {fill, empty}\
    [description: \"you can check whether the mailbox has some mail.\"]\
}\
";

#endif
