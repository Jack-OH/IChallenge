#ifndef __HARDWARE_HOUSE_INFO_H
#define __HARDWARE_HOUSE_INFO_H
const char *hardware_id_str = "N-HOUSE001";
const char schema[] PROGMEM = "\
class door\
{\
    [write]\
    string door; // {open,close}\
    [Description: \"You can open and colse door.\"]\
}\
class alarm\
{\
    [write]\
    string alarm; // {on,off}\
    [Description: \"You can turn alarm on and off.\"]\
}\
class humidity\
{\
    [read]\
    real32 humidity;\
    [Description: \"You can see humidity\"]\
}\
class light\
{\
    [write]\
    string light; // {on,off}\
    [Description: \"You can turn light on and off\"]\
}\
class presence\
{\
    [read]\
    string presence;\ //{occupied, unoccupied}\
    [Description: \"You can check whether someone is in the house.\"]\
}\
class temperature\
{\
    [read]\
    real32 temperature;\
    [Description: \"You can see temperature in degrees celsius\"]\
}";

#endif
