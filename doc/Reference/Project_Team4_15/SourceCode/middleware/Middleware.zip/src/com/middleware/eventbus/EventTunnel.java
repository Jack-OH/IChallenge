package com.middleware.eventbus;

import java.util.ArrayList;

import com.base.protocol.Event;


public class EventTunnel implements IEventTunnel {
    private Object mTrigger; 
    private Thread mWorkerThread;
    private ArrayList<Event> mEventList;
    
    private ArrayList<ITunnelEventSubscriber> mEventSubscriberList;
    
    public EventTunnel() { 
        mTrigger = new Object();
        mEventList = new ArrayList<Event>();
        mEventSubscriberList = new ArrayList<ITunnelEventSubscriber>();
    }
    
    public void initialize() {
        mWorkerThread = new Thread(new Runnable() {
            public void run() {
                while (true) {
                    synchronized (mTrigger) {
                        try {
                            mTrigger.wait();
                            deliver();
                        } catch (InterruptedException ex) {
                            // nothing to do
                        }
                    }                    
                }
            }
        });
        mWorkerThread.start();
    }
    
    private void deliver() {
        synchronized (mEventList) {
            for (Event event : mEventList) {
                deliverOne(event);
            }
            mEventList.clear();
        }        
    }

    private void deliverOne(Event event) {
        synchronized (mEventSubscriberList) {
            String eventAddress = event.getTopicAddress();
            String eventName = event.getTopicName();
            String eventCommand = event.getTopicCommand();
            
            for (ITunnelEventSubscriber subscriber : mEventSubscriberList) {
                 if (subscriber.isSubscribable(eventAddress, eventName, eventCommand)) {
                     deliverEvent(subscriber, event);
                }                    
            }
        }
    }
    
    private void deliverEvent(final ITunnelEventSubscriber subscriber, final Event event) {
        Thread thread = new Thread(new Runnable() {
            public void run() {
                subscriber.onTunnelEventReceived(event);
            } });
        thread.start();
    }
   
    @Override    
    public void sendEvent(Event event) {
        addEvent(event);
        synchronized (mTrigger) {
            mTrigger.notify();
        }
    }
    
    private void addEvent(Event event) {
        synchronized (mEventList) {
            mEventList.add(event);
        }
    }    

    @Override
    public void attachTunnelSubscriber(ITunnelEventSubscriber subscriber) {
        synchronized (mEventSubscriberList) {
            mEventSubscriberList.add(subscriber);
        }
    }
    
    @Override
    public void detachTunnelSubscriber(ITunnelEventSubscriber subscriber) {
        synchronized (mEventSubscriberList) {
            mEventSubscriberList.remove(subscriber);
        }
   }
}
