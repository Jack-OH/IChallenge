package com.dummyclient;

import java.util.ArrayList;

import com.base.client.ClientBase;
import com.base.protocol.Event;
import com.base.protocol.LaonProtocol;



public class DummyClient extends ClientBase {
    private static final String NODE_ID = "N-HOUSE001";
    
    private static final ArrayList<String> mNameList = new ArrayList<String>();

    static {
        mNameList.add(LaonProtocol.NAME_DOOR);
        mNameList.add(LaonProtocol.NAME_ALARM);
        mNameList.add(LaonProtocol.NAME_LIGHT);
        mNameList.add(LaonProtocol.NAME_HUMIDITY);
        mNameList.add(LaonProtocol.NAME_TEMPERATURE);
        mNameList.add(LaonProtocol.NAME_PRESENCE);
        mNameList.add(LaonProtocol.NAME_MAILBOX);
    }
    
    public DummyClient(String clientId) {
        super(clientId);
    }
    
    @Override
    public boolean initialize(String serverIp) {
        boolean result = super.initialize(serverIp);
        if (result) {
            sendStatusCommand();
        }
        return result;
    }
    
    public void sendStatusCommand() {   // test code
        Thread thread = new Thread(new Runnable() {
            synchronized public void run() {
                try {
                    wait(10000);
                    
                    sendControlPublishEvent(LaonProtocol.NAME_ALARM, LaonProtocol.VALUE_ON);
                    
//                    sendControlPublishEvent("door", "open");
//                    wait(3000);
//                    sendControlPublishEvent("light", "on");
//                    wait(3000);
//                    sendEmergencyPublishEvent(LaonProtocol.VALUE_DOOR_OPEN);
//                    wait(3000);
//                    sendEmergencyPublishEvent(LaonProtocol.VALUE_HOUSE_VACANT);
//                    wait(3000);
//                    sendEmergencyPublishEvent(LaonProtocol.VALUE_HOUSE_OCCUPIED);
//                    sendNotifyPublishEvent();
                } catch (InterruptedException e) {
                }
            }
        });
        thread.start();
    }

    private void sendStatusPublishEvent(String name) {
        Event sendEvent = new Event(LaonProtocol.TYPE_PUBLISH_REQ);
        sendEvent.setTopicAddress(NODE_ID);
        sendEvent.setTopicName(name);
        sendEvent.setTopicCommand(LaonProtocol.STATUS_COMMAND);
        sendEvent.setValue("?");
        sendEvent(sendEvent);
    }
    
    private void sendControlPublishEvent(String name, String value) {
        Event sendEvent = new Event(LaonProtocol.TYPE_PUBLISH_REQ);
        sendEvent.setTopicAddress(NODE_ID);
        sendEvent.setTopicName(name);
        sendEvent.setTopicCommand(LaonProtocol.CONTROL_COMMAND);
        sendEvent.setValue(value);
        sendEvent(sendEvent);
    }

    private void sendNotifyPublishEvent() {
        Event sendEvent = new Event(LaonProtocol.TYPE_PUBLISH_REQ);
        sendEvent.setTopicAddress(LaonProtocol.ASTERISK);
        sendEvent.setTopicName(LaonProtocol.NAME_NOTIFIER);
        sendEvent.setTopicCommand(LaonProtocol.CONTENT_COMMAND);
        sendEvent.setValue("4126264726&Emergency from " + NODE_ID);
        sendEvent(sendEvent);
    }   

    private void sendEmergencyPublishEvent(String value) {
        Event sendEvent = new Event(LaonProtocol.TYPE_PUBLISH_REQ);
        sendEvent.setTopicAddress(LaonProtocol.ASTERISK);
        sendEvent.setTopicName(LaonProtocol.NAME_EMERGENCY);
        sendEvent.setTopicCommand(LaonProtocol.CURRENT_COMMAND);
        sendEvent.setValue(value);
        sendEvent(sendEvent);
    }   
    
    @Override
    protected void onConnectAckEventReceived(Event event) {
        super.onPublishReqEventReceived(event);
        registerSubscribe();
    }
 
    private void registerSubscribe() {
        for (String name : mNameList) {
            sendRegisterSubscribeEvent(name, LaonProtocol.CURRENT_COMMAND);
        }
    }
    
    private void sendRegisterSubscribeEvent(String name, String command) {
        Event sendEvent = new Event(LaonProtocol.TYPE_SUBSCRIBE_REQ);
        sendEvent.setTopicAddress(NODE_ID);
        sendEvent.setTopicName(name);
        sendEvent.setTopicCommand(command);
        sendEvent(sendEvent);
    }
    
    @Override
    protected void onPublishReqEventReceived(Event event) {
        super.onPublishReqEventReceived(event);
    }

}
