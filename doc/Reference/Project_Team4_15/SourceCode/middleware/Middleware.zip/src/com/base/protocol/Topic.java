package com.base.protocol;




public class Topic {
    private String mAddress;
    private String mName;
    private String mCommand;
    
    public Topic(String address, String name, String command) {
        mAddress = address;
        mName = name;
        mCommand = command;
    }
    
    public boolean isMatched(String address, String name, String command) {
        return (isSameExpression(mAddress, address) && isSameExpression(mName, name) && isSameExpression(mCommand, command));
    }

    public boolean isMatched(Topic topic) {
        return (isSameExpression(mAddress, topic.mAddress) && isSameExpression(mName, topic.mName) && isSameExpression(mCommand, topic.mCommand));
    }

    private boolean isSameExpression(String a, String b) {
        return (a.equals(LaonProtocol.ASTERISK) || b.equals(LaonProtocol.ASTERISK) || a.equals(b)); 
    }
    
    public boolean equals(Topic topic) {
        return (mAddress.equals(topic.mAddress) && mName.equals(topic.mName) && mCommand.equals(topic.mCommand));
    }
}
