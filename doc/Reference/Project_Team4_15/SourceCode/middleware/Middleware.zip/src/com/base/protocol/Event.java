package com.base.protocol;

import java.nio.ByteBuffer;
import java.util.Arrays;

import com.base.util.MathUtil;


public class Event {
    private int mProtocolId = LaonProtocol.DEFAULT_LAON_PROTOCOL_ID;
    private int mType = LaonProtocol.TYPE_UNKNOWN;
    private int mStart = LaonProtocol.YES;
    private int mLast = LaonProtocol.YES;
    private int mVersion = LaonProtocol.VERSION_1;
    private String mEventSourceId = "          ";
    private int mPacketSequenceNumber = 0;    
    private String mTopicAddress = "";
    private String mTopicName = "";
    private String mTopicCommand = "";
    private String mValue = "";
    
    public Event() {
    }
    
    public Event(int type) {
        mType = type;
    }

    public Event(int type, String sourceId) {
        mType = type;
        setSourceId(sourceId);
    }

    public int getType() {
        return mType;
    }

    public void setType(int type) {
        mType = type;
    }

    public String getSourceId() {
        return mEventSourceId;
    }
 
    public void setSourceId(String sourceId) {
        int length = sourceId.length();
        mEventSourceId = "";
        if (length < LaonProtocol.SOURCE_ID_LENGTH) {
            for (int index = 0; index < LaonProtocol.SOURCE_ID_LENGTH - length; index++) {
                mEventSourceId += " ";
            }
            mEventSourceId += sourceId;
        } else {
            mEventSourceId = sourceId.substring(0, LaonProtocol.SOURCE_ID_LENGTH);
        }
    }

    public String getTopicAddress() {
        return mTopicAddress;
    }
   
    public void setTopicAddress(String address) {
        mTopicAddress = address;
    }
    
    public String getTopicName() {
        return mTopicName;
    }
    
    public void setTopicName(String name) {
        mTopicName = name;
    }
    
    public String getTopicCommand() {
        return mTopicCommand;
    }
    
    public void setTopicCommand(String command) {
        mTopicCommand = command;
    }

    public String getValue() {
        return mValue;
    }
    
    public void setValue(String value) {
        mValue = value;
    }
 
    public void parse(byte[] bytes) {
        mProtocolId = (MathUtil.convertByteToInt(bytes[0]) << 8) + MathUtil.convertByteToInt(bytes[1]);
        int intByte = MathUtil.convertByteToInt(bytes[2]);
        mType = (intByte & LaonProtocol.TYPE_MASK) >> LaonProtocol.TYPE_MASK_SHIFT;
        mStart = (intByte & LaonProtocol.START_MASK) >> LaonProtocol.START_MASK_SHIFT;
        mLast = (intByte & LaonProtocol.LAST_MASK) >> LaonProtocol.LAST_MASK_SHIFT;
        mVersion = (intByte & LaonProtocol.VERSION_MASK) >> LaonProtocol.VERSION_MASK_SHIFT;
        mEventSourceId = new String(Arrays.copyOfRange(bytes, 3, 13));
        mPacketSequenceNumber = MathUtil.convertByteToInt(bytes[13]);

        if (bytes.length > LaonProtocol.HEADER_LENGTH) {
            String content = new String(Arrays.copyOfRange(bytes, LaonProtocol.HEADER_LENGTH, bytes.length));
            String []contentArray = content.split(LaonProtocol.CONTENT_SEPERATORE);

            mTopicAddress = contentArray[1];
            mTopicName = contentArray[2];
            if (contentArray.length > 3) {
                
                String []commandArray = contentArray[3].split(LaonProtocol.VALUE_SEPERATORE);
                mTopicCommand = commandArray[0];
                if (commandArray.length > 1) {
                    int valuePosition = mTopicAddress.length() + mTopicName.length() + mTopicCommand.length() + 4;
                    mValue = content.substring(valuePosition);
                }
            }
        }
    }

    public byte[] getBytes() {        
        byte[] protocolId = new byte[2];
        protocolId[0] = (byte)(mProtocolId >> 8);
        protocolId[1] = (byte)(mProtocolId & 0xff);
        
        byte header = (byte) (mType << LaonProtocol.TYPE_MASK_SHIFT);
        header |= mStart << LaonProtocol.START_MASK_SHIFT;
        header |= mLast << LaonProtocol.LAST_MASK_SHIFT;
        header |= mVersion << LaonProtocol.VERSION_MASK_SHIFT;

        String content = "";
        if (mTopicAddress.length() > 0) {
            content += LaonProtocol.CONTENT_SEPERATORE + mTopicAddress;
            content += LaonProtocol.CONTENT_SEPERATORE + mTopicName;
            content += LaonProtocol.CONTENT_SEPERATORE;
                    
            if (mTopicCommand.length() > 0) {
                content += mTopicCommand;
            }
            content += LaonProtocol.VALUE_SEPERATORE;
            
            if (mValue.length() > 0) {
                content += mValue;
            }
        }
        
        int length = content.length();

        ByteBuffer byteBuffer = ByteBuffer.allocate(length + LaonProtocol.HEADER_LENGTH);
        byteBuffer.put(protocolId);
        byteBuffer.put(header);
        byteBuffer.put(mEventSourceId.getBytes());
        byteBuffer.put((byte)mPacketSequenceNumber);
        byteBuffer.put((byte)(length >> 8));
        byteBuffer.put((byte)(length & 0xff));
        byteBuffer.put(content.getBytes());
        return byteBuffer.array();
    }    
    
    public Topic getTopic() {
        return new Topic(mTopicAddress, mTopicName, mTopicCommand);
    }

    @Override
    public String toString() {
        String string = "";
        string += mProtocolId + " : ";
        string += LaonProtocol.getTypeName(mType) + " : ";
        string += mStart + " : ";
        string += mLast + " : ";
        string += mVersion + " : ";
        string += mEventSourceId + " : ";
        string += mPacketSequenceNumber + " : ";
        string += LaonProtocol.CONTENT_SEPERATORE + mTopicAddress;
        string += LaonProtocol.CONTENT_SEPERATORE + mTopicName;
        string += LaonProtocol.CONTENT_SEPERATORE + mTopicCommand;
        string += LaonProtocol.VALUE_SEPERATORE + mValue;
        return string;
    }   
}
