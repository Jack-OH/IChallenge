package com.base.util;


public class MathUtil {
    public static int convertByteToInt(byte b) {
        return (int)b & 0xff;
    }

}
