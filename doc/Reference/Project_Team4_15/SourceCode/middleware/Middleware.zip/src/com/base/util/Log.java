package com.base.util;


public class Log {
    private static int sId = 0;
    
    public Log() {        
    }
    
    public static void out(String message) {
        System.out.println(sId + " " + message);
        sId++;
    }
}
