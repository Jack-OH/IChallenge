package com.userclient;

import com.base.client.ClientBase;
import com.base.protocol.Event;
import com.base.protocol.LaonProtocol;



public class UserClient extends ClientBase {
    public UserClient(String clientId) {
        super(clientId);
    }
    
    public void sendControlEvent(String address, String name, String value) {
        Event sendEvent = new Event(LaonProtocol.TYPE_PUBLISH_REQ);
        sendEvent.setTopicAddress(address);
        sendEvent.setTopicName(name);
        sendEvent.setTopicCommand(LaonProtocol.CONTROL_COMMAND);
        sendEvent.setValue(value);
        sendEvent(sendEvent);
    }    
}
