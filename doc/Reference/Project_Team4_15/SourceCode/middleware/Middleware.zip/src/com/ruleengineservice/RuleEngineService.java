package com.ruleengineservice;

import java.util.ArrayList;

import com.base.client.ClientBase;
import com.base.protocol.Event;
import com.base.protocol.LaonProtocol;
import com.base.util.DatabaseManager;
import com.base.util.Log;



public class RuleEngineService extends ClientBase {
    private static final ArrayList<String> mNameList = new ArrayList<String>();

    static {
        mNameList.add(LaonProtocol.NAME_REGISTER);
        mNameList.add(LaonProtocol.NAME_EMERGENCY);
        mNameList.add(LaonProtocol.NAME_REGISTER);
        mNameList.add(LaonProtocol.NAME_MAILBOX);
    }
    
    public RuleEngineService(String clientId) {
        super(clientId);
    }
     
    @Override
    protected void onConnectAckEventReceived(Event event) {
        super.onPublishReqEventReceived(event);
        registerSubscribe();
    }
 
    private void registerSubscribe() {
        for (String name : mNameList) {
            sendRegisterSubscribeEvent(name, LaonProtocol.CURRENT_COMMAND);
        }
    }
    
    private void sendRegisterSubscribeEvent(String name, String command) {
        Event sendEvent = new Event(LaonProtocol.TYPE_SUBSCRIBE_REQ);
        sendEvent.setTopicAddress(LaonProtocol.ASTERISK);
        sendEvent.setTopicName(name);
        sendEvent.setTopicCommand(command);
        sendEvent(sendEvent);
    }
    
    @Override
    protected void onSubscribeAckEventReceived(Event event) {
        super.onSubscribeAckEventReceived(event);
        
        if (LaonProtocol.CURRENT_COMMAND.equals(event.getTopicCommand())) {
            if (LaonProtocol.NAME_REGISTER.equals(event.getTopicName())) {
                updateRegisterStatus(event);
            } else if (LaonProtocol.NAME_EMERGENCY.equals(event.getTopicName())) {
                sendEmergencyMessage(event);
            } else if (LaonProtocol.NAME_REGISTER.equals(event.getTopicName())) {
                sendEmergencyMessage(event);
            } else if (LaonProtocol.NAME_MAILBOX.equals(event.getTopicName())) {
                if (LaonProtocol.VALUE_FILL.equals(event.getValue())) {
                    event.setValue(LaonProtocol.VALUE_MAIL_RECEIVED);
                    sendEmergencyMessage(event);
                }
            }
        }
    }

    private void updateRegisterStatus(Event event) {
        DatabaseManager manager = DatabaseManager.getInstance();
        
        if (LaonProtocol.VALUE_JOIN.equals(event.getValue())) {
            // update node status to join
            manager.updateRegisterStatus(event.getTopicAddress(), true);
        } else if (LaonProtocol.VALUE_EXIT.equals(event.getValue())) {
            // update node status to exit            
            manager.updateRegisterStatus(event.getTopicAddress(), false);
            event.setValue(LaonProtocol.VALUE_NODE_DISCONNECTED);
            sendEmergencyMessage(event.getTopicAddress(), event);
        }
    }

    private void sendEmergencyMessage(Event event) {
        sendEmergencyMessage(event.getSourceId(), event);
    }
    
    private void sendEmergencyMessage(String eventSourceId, Event event) {
        String value = event.getValue();
        if (!LaonProtocol.VALUE_DOOR_OPEN.equals(value) 
            && !LaonProtocol.VALUE_HOUSE_VACANT.equals(value)
            && !LaonProtocol.VALUE_HOUSE_OCCUPIED.equals(value)
            && !LaonProtocol.VALUE_MAIL_RECEIVED.equals(value)
            && !LaonProtocol.VALUE_NODE_DISCONNECTED.equals(value)) {
            return;            
        }
        
        DatabaseManager manager = DatabaseManager.getInstance();
        ArrayList<String> addressList = manager.getAddressList(eventSourceId, value);
        String messageText = getMessageText(eventSourceId, event);
        String addressText = getAddressText(eventSourceId, event);
//      addressList.add("4126264726");

        for (String address : addressList) {
            sendEmergencyMessageEvent(address, messageText + "\n" + addressText);
//            sendEmergencyMessageEvent(address, addressText);
        }
    }
    
    private String getMessageText(String eventSourceId, Event event) {
        String format = LaonProtocol.getMessageText(event.getValue());
        String message = "[" + eventSourceId + "]\n";
        message += String.format(format, eventSourceId);
        return message;
    }
    
    private String getAddressText(String eventSourceId, Event event) {
         DatabaseManager manager = DatabaseManager.getInstance();
         String address = manager.getAddress(eventSourceId);
         return String.format(LaonProtocol.ADDRESS_MESSAGE, address);
    }

    private void sendEmergencyMessageEvent(String address, String message) {
        ArrayList<String> addressList = new ArrayList<String>();
        Event event = new Event(LaonProtocol.TYPE_PUBLISH_REQ);
        event.setTopicAddress(LaonProtocol.ASTERISK);
        event.setTopicName(LaonProtocol.NAME_NOTIFIER);
        event.setTopicCommand(LaonProtocol.CONTENT_COMMAND);
        event.setValue(address + LaonProtocol.ARGUMENT_SEPERATORE + message);
        sendEvent(event);
    }
}
