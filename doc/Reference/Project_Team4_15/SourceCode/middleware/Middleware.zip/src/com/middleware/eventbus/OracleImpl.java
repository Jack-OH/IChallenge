package com.middleware.eventbus;

import java.net.Socket;

import com.base.protocol.Event;
import com.base.protocol.LaonProtocol;


public class OracleImpl extends Oracle {
    private static final String NODE_ID = "IamORACLE!";    
    private String mParticiantId = "";
    
    public OracleImpl(Socket socket, IEventTunnel tunnel) {
        super(socket, tunnel);
    }
    
    protected void onUnknownEventReceived(Event event) {
        ban();    // unknown means ban!
    }

    protected void onConnectReqEventReceived(Event event) {
        // Authentication
        RegistrationManager manager = RegistrationManager.getInstance();
        if (manager.isRegistered(event.getSourceId())) {
            // registered
            mParticiantId = event.getSourceId();

            participate();
            sendEvent(new Event(LaonProtocol.TYPE_CONNECT_ACK, NODE_ID));
            sendRegisterEvent(mParticiantId, true);
            updateSchema(mParticiantId, event.getValue());
        } else {
            ban();
        }        
    }
    
    protected void onDisconnected() {
        sendRegisterEvent(mParticiantId, false);        
        super.onDisconnected();
    }

    private void sendRegisterEvent(String address, boolean registered) {
        Event event = new Event(LaonProtocol.TYPE_SUBSCRIBE_ACK, NODE_ID);
        event.setTopicAddress(address);
        event.setTopicName(LaonProtocol.NAME_REGISTER);
        event.setTopicCommand(LaonProtocol.CURRENT_COMMAND);
        if (registered) {
            event.setValue(LaonProtocol.VALUE_JOIN);
        } else {
            event.setValue(LaonProtocol.VALUE_EXIT);
        }
        sendTunnelEvent(event);
    }

    private void updateSchema(String mParticiantId, String schema) {
        // update schema
        if (schema == null || schema.length() == 0) {
            return;
        }
        RegistrationManager manager = RegistrationManager.getInstance();
        manager.storeSchema(mParticiantId, schema);
    }

    protected void onPublishReqEventReceived(Event event) {
        event.setType(LaonProtocol.TYPE_SUBSCRIBE_ACK);
        sendTunnelEvent(event);
        sendEvent(new Event(LaonProtocol.TYPE_PUBLISH_ACK, NODE_ID));
    }
    
    protected void onSubscribeReqEventReceived(Event event) {
        addTopic(event.getTopic());
        sendEvent(new Event(LaonProtocol.TYPE_SUBSCRIBE_ACK, NODE_ID));
    }
    
    protected void onUnsubscribeReqEventReceived(Event event) {
        removeTopic(event.getTopic());
        sendEvent(new Event(LaonProtocol.TYPE_UNSUBSCRIBE_ACK, NODE_ID));
    }

    protected void onPingReqEventReceived(Event event) {
        // really need it?
    }
    
    protected void onDisconnectReqEventReceived(Event event) {
        onDisconnected();
    }
    
    @Override
    public String toString() {
        return mParticiantId;
    }   
}
