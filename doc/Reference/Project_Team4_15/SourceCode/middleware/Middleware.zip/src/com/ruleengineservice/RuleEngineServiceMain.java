package com.ruleengineservice;

import com.base.client.ClientBase;


public class RuleEngineServiceMain {
    private static final String DEFAULT_SERVER_IP = "127.0.0.1";
    private static final String CLIENT_ID = "S-RULEENG1";
    
    public static void main(String[] args) {
        ClientBase client = new RuleEngineService(CLIENT_ID);
        if (client.initialize(DEFAULT_SERVER_IP)) {
            client.launch();
        }
    }
}
