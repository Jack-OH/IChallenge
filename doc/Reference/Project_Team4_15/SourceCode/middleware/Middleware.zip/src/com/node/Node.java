package com.node;

import java.util.ArrayList;

import com.base.client.ClientBase;
import com.base.protocol.Event;
import com.base.protocol.LaonProtocol;



public class Node extends ClientBase {


    private static final ArrayList<String> mNameList = new ArrayList<String>();

    static {
        mNameList.add("door");
        mNameList.add("alarm");
        mNameList.add("light");
        mNameList.add("humidity");
        mNameList.add("temperature");
        mNameList.add("presence");
        mNameList.add("mailbox");
    }
    
    public Node(String clientId) {
        super(clientId);
    }
    
    @Override
    protected void onConnectAckEventReceived(Event event) {
        super.onConnectAckEventReceived(event);
        registerSubscribe();
    }
    
    private void registerSubscribe() {
        // unstable
        Event sendEvent;
        for (String name : mNameList) {
            sendRegisterSubscribeEvent(name, LaonProtocol.CONTROL_COMMAND);
            sendRegisterSubscribeEvent(name, LaonProtocol.STATUS_COMMAND);
        }
    }
    
    private void sendRegisterSubscribeEvent(String name, String command) {
        Event sendEvent = new Event(LaonProtocol.TYPE_SUBSCRIBE_REQ);
        sendEvent.setTopicAddress(getClientId());
        sendEvent.setTopicName(name);
        sendEvent.setTopicCommand(command);
        sendEvent(sendEvent);
    }
    
    @Override
    protected void onSubscribeAckEventReceived(Event event) {
        super.onSubscribeAckEventReceived(event);

        if (LaonProtocol.STATUS_COMMAND.equals(event.getTopicCommand())) {
            publishStatusEvent(event.getTopicName());
        }
    }
    
    private void publishStatusEvent(String name) {
        Event event = new Event(LaonProtocol.TYPE_PUBLISH_REQ);
        event.setTopicAddress(getClientId());
        event.setTopicName(name);
        event.setTopicCommand(LaonProtocol.CURRENT_COMMAND);
        event.setValue("10");    // just run as an echo server now.
        sendEvent(event);
    }
}
