package com.middleware.eventbus;

import com.base.protocol.Event;


public interface IEventTunnel { 
    public void sendEvent(Event event);
    public void attachTunnelSubscriber(ITunnelEventSubscriber subscriber);    
    public void detachTunnelSubscriber(ITunnelEventSubscriber subscriber);
}
