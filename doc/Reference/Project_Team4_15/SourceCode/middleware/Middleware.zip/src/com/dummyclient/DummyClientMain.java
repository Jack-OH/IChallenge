package com.dummyclient;

import com.base.client.ClientBase;


public class DummyClientMain {
    private static final String DEFAULT_SERVER_IP = "127.0.0.1";
    private static final String CLIENT_ID = "S-TOMCAT02";

    public static void main(String[] args) {
        ClientBase client = new DummyClient(CLIENT_ID);
        if (client.initialize(DEFAULT_SERVER_IP)) {
            client.launch();
        }
    }
}
