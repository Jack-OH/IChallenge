package com.base.protocol;

import java.util.HashMap;


public class LaonProtocol {
    public static final int HEARTBEAT_PERIOD = 5000;   // 10 sec
    
    public static final byte TYPE_MASK = (byte)0xF0;
    public static final int TYPE_MASK_SHIFT = 4;
    public static final int TYPE_UNKNOWN = 0;
    public static final int TYPE_CONNECT_REQ = 1;
    public static final int TYPE_CONNECT_ACK = 2;
    public static final int TYPE_PUBLISH_REQ = 3;
    public static final int TYPE_PUBLISH_ACK = 4;
    public static final int TYPE_SUBSCRIBE_REQ = 5;
    public static final int TYPE_SUBSCRIBE_ACK = 6;
    public static final int TYPE_UNSUBSCRIBE_REQ = 7;
    public static final int TYPE_UNSUBSCRIBE_ACK = 8;
    public static final int TYPE_PING_REQ = 9;
    public static final int TYPE_PING_ACK = 10;
    public static final int TYPE_DISCONNECT_REQ = 11;
    
    public static final byte START_MASK = 0x08;
    public static final int START_MASK_SHIFT = 3;
    
    public static final byte LAST_MASK = 0x04;
    public static final int LAST_MASK_SHIFT = 2;

    public static final byte VERSION_MASK = 0x03;
    public static final int VERSION_MASK_SHIFT = 0;
    
    public static final int DEFAULT_LAON_PROTOCOL_ID = 0x1a0e;
    public static final int NO = 0;
    public static final int YES = 1;
    public static final int VERSION_1 = 1;
    
    public static final String CONTENT_SEPERATORE = "/";
    public static final String VALUE_SEPERATORE = "=";
    public static final String ARGUMENT_SEPERATORE = "&";
    
    public static final int HEADER_LENGTH = 16;
    
    public static final String ASTERISK = "*";
    public static final String ADMIN_ID_PREFIX = "AD";
    public static final int SOURCE_ID_LENGTH = 10;
    
    public static final String NAME_DOOR = "door";
    public static final String NAME_ALARM = "alarm";
    public static final String NAME_LIGHT = "light";
    public static final String NAME_HUMIDITY = "humidity";
    public static final String NAME_TEMPERATURE = "temperature";
    public static final String NAME_PRESENCE = "presence";
    public static final String NAME_MAILBOX = "mailbox";
    public static final String NAME_REGISTER = "register";
    public static final String NAME_EMERGENCY = "emergency";
    public static final String NAME_NOTIFIER = "notifier";
    public static final String NAME_POLICY = "policy";
    
    public static final String CONTROL_COMMAND = "control";
    public static final String STATUS_COMMAND = "status";
    public static final String CURRENT_COMMAND = "current";
    public static final String CONTENT_COMMAND = "content";
    
    public static final String VALUE_ON = "on";
    public static final String VALUE_OFF = "off";
    public static final String VALUE_JOIN = "join";
    public static final String VALUE_EXIT = "exit";
    public static final String VALUE_FILL = "fill";
    public static final String VALUE_EMPTY = "empty";
    public static final String VALUE_DOOR_OPEN = "door open while alarmed";
    public static final String VALUE_HOUSE_VACANT = "house vacant while not alarmed";
    public static final String VALUE_HOUSE_OCCUPIED = "house occupied while alarmed";
    public static final String VALUE_MAIL_RECEIVED = "mail is received";
    public static final String VALUE_NODE_DISCONNECTED = "sa node is disconnected";
    
//    public static final String ADDRESS_MESSAGE = "The house address is '%s'.";
    public static final String ADDRESS_MESSAGE = "Address : %s";
    
    private static final HashMap<Integer, String> mTypeNameMap = new HashMap<Integer, String>();
    private static final HashMap<String, String> mMessageMap = new HashMap<String, String>();
    private static final HashMap<String, String> mSecondMessageMap = new HashMap<String, String>();
     
    static {
        mTypeNameMap.put(Integer.valueOf(TYPE_UNKNOWN), "TYPE_UNKNOWN"); 
        mTypeNameMap.put(Integer.valueOf(TYPE_CONNECT_REQ), "TYPE_CONNECT_REQ"); 
        mTypeNameMap.put(Integer.valueOf(TYPE_CONNECT_ACK), "TYPE_CONNECT_ACK"); 
        mTypeNameMap.put(Integer.valueOf(TYPE_PUBLISH_REQ), "TYPE_PUBLISH_REQ"); 
        mTypeNameMap.put(Integer.valueOf(TYPE_PUBLISH_ACK), "TYPE_PUBLISH_ACK"); 
        mTypeNameMap.put(Integer.valueOf(TYPE_SUBSCRIBE_REQ), "TYPE_SUBSCRIBE_REQ"); 
        mTypeNameMap.put(Integer.valueOf(TYPE_SUBSCRIBE_ACK), "TYPE_SUBSCRIBE_ACK"); 
        mTypeNameMap.put(Integer.valueOf(TYPE_UNSUBSCRIBE_REQ), "TYPE_UNSUBSCRIBE_REQ"); 
        mTypeNameMap.put(Integer.valueOf(TYPE_UNSUBSCRIBE_ACK), "TYPE_UNSUBSCRIBE_ACK"); 
        mTypeNameMap.put(Integer.valueOf(TYPE_PING_REQ), "TYPE_PING_REQ"); 
        mTypeNameMap.put(Integer.valueOf(TYPE_PING_ACK), "TYPE_PING_ACK"); 
        mTypeNameMap.put(Integer.valueOf(TYPE_DISCONNECT_REQ), "TYPE_DISCONNECT_REQ"); 

        mMessageMap.put(VALUE_DOOR_OPEN, "The house is manually opened while alarmed."); 
        mMessageMap.put(VALUE_HOUSE_VACANT, "The house is not alarmed and vacent. Please, check it."); 
        mMessageMap.put(VALUE_HOUSE_OCCUPIED, "The house is suddenly occupied while alarmed."); 
        mMessageMap.put(VALUE_MAIL_RECEIVED, "A mail has been received on the house."); 
        mMessageMap.put(VALUE_NODE_DISCONNECTED, "The '%s' on the house is disconnected."); 
    }
    
    public static String getTypeName(int type) {
        return mTypeNameMap.get(Integer.valueOf(type));
    }
    
    public static String getMessageText(String value) {
        return mMessageMap.get(value);
    }
}
