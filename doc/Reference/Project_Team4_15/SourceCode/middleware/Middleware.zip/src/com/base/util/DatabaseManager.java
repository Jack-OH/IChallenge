package com.base.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.base.protocol.LaonProtocol;

//import org.sqlite.SQLiteConfig;

public class DatabaseManager {
	private Connection mConnection;
	public boolean mIsOpened = false;
	private static final String DB_NAME = "laon45";
	private static final String DATABASE_URL = "jdbc:mysql://192.168.1.104:3306";

	public static final String TABLE_HOUSE = "house";
	public static final String TABLE_NODE = "node";
	public static final String TABLE_USER = "user";
	public static final String TABLE_USER_HOUSE_MAP = "user_house_map";
	public static final String TABLE_USER_NODE_MAP = "user_node_map";
	public static final String TABLE_EMERGENCY_SMS = "emergency_sms";
	public static final String TABLE_LOG = "log";
	public static final String TABLE_NODE_STATUS = "node_status";
	
	private DatabaseManager() {
		try {
			createDb();
		} catch(Exception e) {
		    e.printStackTrace(); 
	    }
	}
	
	private static DatabaseManager sInstance;
	
	public static DatabaseManager getInstance() {
		if (sInstance == null) {
			sInstance = new DatabaseManager();
		}

		return sInstance;
	}

	public static void createDb() {
        try {
            Connection connection = DriverManager.getConnection(DATABASE_URL, "admin", "1234");
            Statement statement = connection.createStatement();
            
            ResultSet resultSet = null;
            resultSet = statement.executeQuery("SHOW DATABASES LIKE " + "'" + DB_NAME + "'");

            if (resultSet.next() == false) {
                statement.executeUpdate("create database " + DB_NAME);
                createTable();
                Log.out(DB_NAME + " created");
            }
            connection.close();
        } catch (Exception e) {
            Log.out("MySql exception");
            Log.out(e.getMessage());
        }
    }

    private static void createTable() {
    	try {
            String myDbUrl = DATABASE_URL + "/" + DB_NAME;
            Connection connection = DriverManager.getConnection(myDbUrl, "admin", "1234");
    		Statement statement = connection.createStatement();

    		statement.executeUpdate("CREATE TABLE IF NOT EXISTS user(" +
    				"id int(10) unsigned not null auto_increment primary key," +
    				"name varchar(20) not null," +
    				"login_id varchar(20) unique not null," +
    				"password varchar(20) default '0000' not null," +
    				"hwid varchar(20) unique not null);");

    		statement.executeUpdate("CREATE TABLE IF NOT EXISTS house(" +
    				"id int(10) unsigned not null auto_increment primary key," +
    				"address varchar(200) unique not null);");

    		statement.executeUpdate("CREATE TABLE IF NOT EXISTS node(" +
    				"id int(10) unsigned not null auto_increment primary key" +
    				",name varchar(20) unique not null," +
    				"password varchar(20) default '0000'," +
    				"house_address varchar(200) not null," +
    				"status varchar(20)," +
    				"property varchar(2000));");

    		statement.executeUpdate("CREATE TABLE IF NOT EXISTS user_house_map(" +
    				"id int(10) unsigned not null auto_increment primary key," +
    				"login_id varchar(20) not null," +
    				"house_address varchar(200) not null);");

    		statement.executeUpdate("CREATE TABLE IF NOT EXISTS user_node_map(" +
    				"id int(10) unsigned not null auto_increment primary key," +
    				"login_id varchar(20) not null," +
    				"node_name varchar(20) not null);");

    		statement.executeUpdate("CREATE TABLE IF NOT EXISTS emergency_sms(id int(10) unsigned not null auto_increment primary key," +
    				"node_name varchar(20), telephone varchar(20)," +
    				"event_case varchar(50));");

    		statement.executeUpdate("CREATE TABLE IF NOT EXISTS log(" +
    				"id int(10) unsigned not null auto_increment primary key," +
    				"timestamp timestamp default current_timestamp," +
    				"source varchar(20)," +
    				"destination varchar(20)," +
    				"name varchar(20)," +
    				"command varchar(50)," +
    				"value varchar(500));");

    		statement.executeUpdate("CREATE TABLE IF NOT EXISTS node_status(" +
    				"id int(10) unsigned not null auto_increment primary key," +
    				"name varchar(20)," +
    				"sensor varchar(20)," +
    				"value varchar(500));");
    		insertPresetValues(statement);
		} catch(SQLException e) { 
			e.printStackTrace();
		}
    }

    private static void insertPresetValues(Statement statement) {
        try {
            statement.executeUpdate("insert into user (name, login_id, password, hwid) values ('admin','admin','0000','U-ADMIN001');");
            statement.executeUpdate("insert into user (name, login_id, password, hwid) values ('laon','laon','0000','U-LAON0001');");
            //statement.executeUpdate("insert into user (name, login_id, password, hwid) values ('WOO','WOO','0000','U-WOO00001');");
            //statement.executeUpdate("insert into user (name, login_id, password, hwid) values ('CHOE','CHOE','0000','U-CHOE0001');");
            //statement.executeUpdate("insert into user (name, login_id, password, hwid) values ('LIM','LIM','0000','U-LIM00001');");
            //statement.executeUpdate("insert into user (name, login_id, password, hwid) values ('KIM','KIM','0000','U-KIM00001');");
            //statement.executeUpdate("insert into user (name, login_id, password, hwid) values ('KWON','KWON','0000','U-KWON0001');");
            //statement.executeUpdate("insert into user (name, login_id, password, hwid) values ('JANG','JANG','0000','U-JANG0001');");
            
            statement.executeUpdate("insert into house (address) values ('laon system');");
            statement.executeUpdate("insert into house (address) values ('team4');");
            //statement.executeUpdate("insert into house (address) values ('5405 Fifth Ave');");
            //statement.executeUpdate("insert into house (address) values ('5000 Forbes Ave');");
            //statement.executeUpdate("insert into house (address) values ('300 S Craig St');");
            //statement.executeUpdate("insert into house (address) values ('4400 Forbes Ave');");

            statement.executeUpdate("insert into node (name, password, house_address) values ('N-HOUSE001', '0000', 'team4');");
            //statement.executeUpdate("insert into node (name, password, house_address) values ('N-HOUSE002', '0000', 'team4');");
            //statement.executeUpdate("insert into node (name, password, house_address) values ('N-HOUSE003', '0000', 'team4');");
            statement.executeUpdate("insert into node (name, password, house_address) values ('N-MAILBOX1', '0000', 'team4');");

            statement.executeUpdate("insert into node (name, password, house_address) values ('S-TOMCAT01', '0000', 'laon system');");
            statement.executeUpdate("insert into node (name, password, house_address) values ('S-TOMCAT02', '0000', 'laon system');");
            statement.executeUpdate("insert into node (name, password, house_address) values ('S-LOGGER01', '0000', 'laon system');");
            statement.executeUpdate("insert into node (name, password, house_address) values ('S-MESSAGE1', '0000', 'laon system');");
            statement.executeUpdate("insert into node (name, password, house_address) values ('S-DATABASE', '0000', 'laon system');");
            statement.executeUpdate("insert into node (name, password, house_address) values ('S-RULEENG1', '0000', 'laon system');");
            
            statement.executeUpdate("insert into user_house_map (login_id, house_address) values ('laon', 'team4');");

            statement.executeUpdate("insert into user_node_map (login_id, node_name) values ('laon', 'N-HOUSE001');");
//            statement.executeUpdate("insert into user_node_map (login_id, node_name) values ('laon', 'N-HOUSE002');");
//            statement.executeUpdate("insert into user_node_map (login_id, node_name) values ('laon', 'N-HOUSE003');");
            statement.executeUpdate("insert into user_node_map (login_id, node_name) values ('laon', 'N-MAILBOX1');");
            statement.executeUpdate("insert into user_node_map (login_id, node_name) values ('admin', 'S-TOMCAT01');");
            statement.executeUpdate("insert into user_node_map (login_id, node_name) values ('admin', 'S-TOMCAT02');");
            statement.executeUpdate("insert into user_node_map (login_id, node_name) values ('admin', 'S-LOGGER01');");
            statement.executeUpdate("insert into user_node_map (login_id, node_name) values ('admin', 'S-MESSAGE1');");
            statement.executeUpdate("insert into user_node_map (login_id, node_name) values ('admin', 'S-DATABASE');");
            statement.executeUpdate("insert into user_node_map (login_id, node_name) values ('admin', 'S-RULEENG1');");

            statement.executeUpdate("insert into emergency_sms (node_name, telephone, event_case) values ('N-HOUSE001', '9174029218', 'door open while alarmed');");
            statement.executeUpdate("insert into emergency_sms (node_name, telephone, event_case) values ('N-HOUSE001', '9174029218', 'house vacant while not alarmed');");
            statement.executeUpdate("insert into emergency_sms (node_name, telephone, event_case) values ('N-HOUSE001', '9174029218', 'house occupied while alarmed');");
            statement.executeUpdate("insert into emergency_sms (node_name, telephone, event_case) values ('N-HOUSE001', '9174029218', 'sa node is disconnected');");
            statement.executeUpdate("insert into emergency_sms (node_name, telephone, event_case) values ('N-MAILBOX1', '9174029218', 'mail is received');");
//            statement.executeUpdate("insert into emergency_sms (node_name, telephone, event_case) values ('N-MAILBOX1', '4126264726', 'mail is received');"); // me
//            statement.executeUpdate("insert into emergency_sms (node_name, telephone, event_case) values ('N-MAILBOX1', '4122684736', 'mail is received');"); // Tony
//            statement.executeUpdate("insert into emergency_sms (node_name, telephone, event_case) values ('N-MAILBOX1', '4122253427', 'mail is received');"); // Jeff          
            statement.executeUpdate("insert into emergency_sms (node_name, telephone, event_case) values ('N-MAILBOX1', '9174029218', 'sa node is disconnected');");

            statement.executeUpdate("insert into emergency_sms (node_name, telephone, event_case) values ('N-HOUSE002', '9174029218', 'door open while alarmed');");
            statement.executeUpdate("insert into emergency_sms (node_name, telephone, event_case) values ('N-HOUSE002', '9174029218', 'house vacant while not alarmed');");
            statement.executeUpdate("insert into emergency_sms (node_name, telephone, event_case) values ('N-HOUSE002', '9174029218', 'house occupied while alarmed');");
            statement.executeUpdate("insert into emergency_sms (node_name, telephone, event_case) values ('N-HOUSE002', '9174029218', 'sa node is disconnected');");
            statement.executeUpdate("insert into emergency_sms (node_name, telephone, event_case) values ('N-MAILBOX2', '9174029218', 'mail is received');");
            statement.executeUpdate("insert into emergency_sms (node_name, telephone, event_case) values ('N-MAILBOX2', '9174029218', 'sa node is disconnected');");

            statement.executeUpdate("insert into emergency_sms (node_name, telephone, event_case) values ('N-HOUSE003', '9174029218', 'door open while alarmed');");
            statement.executeUpdate("insert into emergency_sms (node_name, telephone, event_case) values ('N-HOUSE003', '9174029218', 'house vacant while not alarmed');");
            statement.executeUpdate("insert into emergency_sms (node_name, telephone, event_case) values ('N-HOUSE003', '9174029218', 'house occupied while alarmed');");
            statement.executeUpdate("insert into emergency_sms (node_name, telephone, event_case) values ('N-HOUSE003', '9174029218', 'sa node is disconnected');");
            statement.executeUpdate("insert into emergency_sms (node_name, telephone, event_case) values ('N-MAILBOX3', '9174029218', 'mail is received');");
            statement.executeUpdate("insert into emergency_sms (node_name, telephone, event_case) values ('N-MAILBOX3', '9174029218', 'sa node is disconnected');");

            statement.executeUpdate("insert into emergency_sms (node_name, telephone, event_case) values ('N-HOUSE004', '9174029218', 'door open while alarmed');");
            statement.executeUpdate("insert into emergency_sms (node_name, telephone, event_case) values ('N-HOUSE004', '9174029218', 'house vacant while not alarmed');");
            statement.executeUpdate("insert into emergency_sms (node_name, telephone, event_case) values ('N-HOUSE004', '9174029218', 'house occupied while alarmed');");
            statement.executeUpdate("insert into emergency_sms (node_name, telephone, event_case) values ('N-HOUSE004', '9174029218', 'sa node is disconnected');");

            statement.executeUpdate("insert into emergency_sms (node_name, telephone, event_case) values ('N-HOUSE005', '9174029218', 'door open while alarmed');");
            statement.executeUpdate("insert into emergency_sms (node_name, telephone, event_case) values ('N-HOUSE005', '9174029218', 'house vacant while not alarmed');");
            statement.executeUpdate("insert into emergency_sms (node_name, telephone, event_case) values ('N-HOUSE005', '9174029218', 'house occupied while alarmed');");
            statement.executeUpdate("insert into emergency_sms (node_name, telephone, event_case) values ('N-HOUSE005', '9174029218', 'sa node is disconnected');");

        } catch(SQLException e) { 
            e.printStackTrace();
        }
    }
    
    public boolean open() {
		try {
			String myDbUrl = DATABASE_URL + "/" + DB_NAME;
            mConnection = DriverManager.getConnection(myDbUrl, "admin", "1234");
		} catch(SQLException e) { 
			e.printStackTrace();
			return false;
		}

		mIsOpened = true;
		return true;
	}

	public boolean close() {
		if (mIsOpened == false) {
			return true;
		}

		try {
			mConnection.close();
		} catch(SQLException e) { 
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public int insert(String table, String[] values) {
		int result = 0;
		try {
			PreparedStatement preparedStatement = null;
			String sql = "insert into " + table;
			if (table == null) {
			} else if (table.equals(TABLE_USER)) {
				sql += "(name,login_id,password,hwid) values(?,?,?,?);";
				preparedStatement = mConnection.prepareStatement(sql);
				preparedStatement.setString(1, values[0]);
				preparedStatement.setString(2, values[1]);
				preparedStatement.setString(3, values[2]);
				preparedStatement.setString(4, values[3]);
			} else if (table.equals(TABLE_HOUSE)) {
				sql += "(address) values(?);";
				preparedStatement = mConnection.prepareStatement(sql);
				preparedStatement.setString(1, values[0]);
			} else if (table.equals(TABLE_NODE)) {
				sql += "(name,password,house_address) values(?,?,?);";
				preparedStatement = mConnection.prepareStatement(sql);
				preparedStatement.setString(1, values[0]);
				preparedStatement.setString(2, values[1]);
				preparedStatement.setString(3, values[2]);
			} else if (table.equals(TABLE_USER_HOUSE_MAP)) {
				sql += "(login_id,house_address) values(?,?)";
				preparedStatement = mConnection.prepareStatement(sql);
				preparedStatement.setString(1, values[0]);
				preparedStatement.setString(2, values[1]);
			} else if (table.equals(TABLE_USER_NODE_MAP)) {
				sql += "(login_id,node_name) values(?,?)";
				preparedStatement = mConnection.prepareStatement(sql);
				preparedStatement.setString(1, values[0]);
				preparedStatement.setString(2, values[1]);
			} else if (table.equals(TABLE_EMERGENCY_SMS)) { 
				sql += "(node_name, telephone, event_case) values(?,?,?)";
				preparedStatement = mConnection.prepareStatement(sql);
				preparedStatement.setString(1, values[0]);
				preparedStatement.setString(2, values[1]);
				preparedStatement.setString(2, values[2]);
			} else if (table.equals(TABLE_LOG)) {
				sql += "(timestamp, source, destination, name, command, value) values(?,?,?,?,?,?);";
				preparedStatement = mConnection.prepareStatement(sql);
				preparedStatement.setString(1, null);
				preparedStatement.setString(2, values[1]);
				preparedStatement.setString(3, values[2]);
				preparedStatement.setString(4, values[3]);
				preparedStatement.setString(5, values[4]);
				preparedStatement.setString(6, values[5]);
			} else if (table.equals(TABLE_NODE_STATUS)) { 
				sql += "(name, sensor, value) values(?,?,?)";
				preparedStatement = mConnection.prepareStatement(sql);
				preparedStatement.setString(1, values[0]);
				preparedStatement.setString(2, values[1]);
				preparedStatement.setString(3, values[2]);
			}
			result = preparedStatement.executeUpdate();
			if(table.equals(TABLE_LOG)) {
				if("current".equals(values[4])) {
					delete(TABLE_NODE_STATUS, "name=? and sensor=?", new String[] { values[2], values[3] });
					insert(TABLE_NODE_STATUS, new String[] { values[2], values[3], values[5] });
				}
			}
		} catch(SQLException e) { 
			e.printStackTrace();
			return result;
		}

		return result;
	}

	public int update(String table, String where, String[] whereArgs) {
		int result = 0;
		try {
			PreparedStatement preparedStatement = null;
			String sql = "update " + table + " set " + where + ";";
			preparedStatement = mConnection.prepareStatement(sql);
			for (int i = 0; whereArgs != null && i < whereArgs.length; i++) {
				preparedStatement.setString(i+1, whereArgs[i]);
			}
			result = preparedStatement.executeUpdate();
		} catch(SQLException e) { 
			e.printStackTrace();
			return result;
		}

		return result;
	}

	public int delete(String table, String where, String[] whereArgs) {
		int result = 0;
		try {
			PreparedStatement preparedStatement = null;
			String sql = "delete from " + table + " where " + where + ";";
			preparedStatement = mConnection.prepareStatement(sql);
			for (int i = 0; whereArgs != null && i < whereArgs.length; i++) {
				preparedStatement.setString(i+1, whereArgs[i]);
			}
			result = preparedStatement.executeUpdate();
		} catch(SQLException e) { 
			e.printStackTrace();
			return result;
		}

		return result;
	}

	public ResultSet query(String table, String where, String[] whereArgs) {
		ResultSet resultSet = null;
		try {
			PreparedStatement preparedStatement = null;
			String sql = "select * from " + table + " where " + where + ";";
			preparedStatement = mConnection.prepareStatement(sql);
			for (int i = 0; whereArgs != null && i < whereArgs.length; i++) {
				preparedStatement.setString(i+1, whereArgs[i]);
			}
			resultSet = preparedStatement.executeQuery();
		} catch(SQLException e) { 
			e.printStackTrace();
			return resultSet;
		}

		return resultSet;
	}

    public boolean isRegistered(String nodeId) {
        if (nodeId.startsWith(LaonProtocol.ADMIN_ID_PREFIX)) {
            return true;
        }
        
        // query to DB & return the result
        boolean result = false;
        open();
        
        if (!isAvailable()) {
            return result;
        }
        
        ResultSet rs = query(DatabaseManager.TABLE_NODE, "name=?", new String[] {nodeId});
        try {
            result = rs.next();
            if (result == false) {
                rs = query(DatabaseManager.TABLE_USER, "hwid=?", new String[] {nodeId});
                result = rs.next();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } 
        close();
        return result;
    }
    
	public String getAddress(String node_name) {
		ResultSet resultSet = null;
		String result = null;
        open();
		try {
			PreparedStatement preparedStatement = null;
			String sql = "select * from house join node ON house.address=node.house_address and name=?;";
			preparedStatement = mConnection.prepareStatement(sql);
			preparedStatement.setString(1, node_name);

			resultSet = preparedStatement.executeQuery();
			resultSet.next();
			result = resultSet.getString("address");
		} catch(SQLException e) {
			e.printStackTrace();
			return result;
		}
        close();
		return result;
	}
	
	public void updateRegisterStatus(String nodeId, boolean registered) {
        String where = null;
        String[] whereArgs = new String[] {nodeId};
        open();
        if (registered) {
            // update node status to join
            where = "status='connected' where name=?";
            update(TABLE_NODE, where, whereArgs);
        } else {
            // update node status to exit
            where = "status='disconnected' where name=?";
            update(TABLE_NODE, where, whereArgs);
        }
        close();
    }
	
	public ArrayList<String> getAddressList(String nodeId, String eventCase) {
        ArrayList<String> addressList = new ArrayList<String>();
        String where = "node_name=? and event_case=?";
        String[] whereArgs = new String[] {nodeId, eventCase };
        ResultSet resultSet = null;
     
        open();
        resultSet = query(DatabaseManager.TABLE_EMERGENCY_SMS, where, whereArgs);
        try {
            while(resultSet.next()) {
                addressList.add(resultSet.getString("telephone"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        close();
        return addressList;
    }

	public boolean isRegisteredUser(String login_id, String password) {
		String where = "login_id=? and password=?";
        String[] whereArgs = new String[] {login_id, password };
        ResultSet resultSet = null;
        boolean result = false;
     
        open();
        resultSet = query(DatabaseManager.TABLE_USER, where, whereArgs);
        try {
			result = resultSet.next();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        close();
		return result;
	}

	public String registerNode(String node_name, String node_password, String login_id, String house_address) {
        String where = "login_id=? and house_address=?";
        String[] whereArgs = new String[] {login_id, house_address };
        ResultSet resultSet = null;
        String result = null;

        open();
		try {
			resultSet = query(DatabaseManager.TABLE_USER_HOUSE_MAP, where, whereArgs);
			if(resultSet.next()) {
				result = "ok";
			} else {
				result = "wrong login id or house address";
				return result;
			}
			insert(TABLE_NODE, new String[] {node_name, node_password, house_address});
			insert(TABLE_USER_NODE_MAP, new String[] { login_id, node_name });
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        close();
        return result;
	}

	public boolean isAvailable() {
        return (mConnection != null);
    }
}
