package com.base.client;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Arrays;

import com.base.protocol.Event;
import com.base.protocol.LaonProtocol;
import com.base.util.Log;
import com.base.util.MathUtil;



abstract public class ClientBase extends Thread {
    private static final int SERVER_PORT = 550;
    private static final int BUFFER_SIZE = 4 * 1024; // 4kb
    
    private Socket mSocket;
    private boolean mBanTrigger = false;
    private boolean mIsRegistered = false;
    private String mClientId = "          ";
   
    public ClientBase(String clientId) {
        mClientId = clientId;
    }
    
    public boolean initialize(String serverIp) {
        try {
            mSocket = new Socket(serverIp, SERVER_PORT);
//            mSocket.setSoTimeout(0);
        } catch (UnknownHostException e) {
            Log.out("Unable to connect to the server");
            return false;
        } catch (IOException e) {
            Log.out("Unable to connect to the server");
            return false;
        }
        return true;
    }
    
    public void launch() {
        sendEvent(new Event(LaonProtocol.TYPE_CONNECT_REQ));
        start();
    }
   
    private byte[] receiveEvent() {
        byte[] buffer = new byte[BUFFER_SIZE];
        int bytesRead = 0;
        int lengthLeft = LaonProtocol.HEADER_LENGTH;
        
        try {
            InputStream inputStream = mSocket.getInputStream();
            while (!mBanTrigger) {
                int length = inputStream.read(buffer, bytesRead, lengthLeft);
                if (length < 0) {                    
                    onDisconnected();
                    break;
                }
                bytesRead += length;
                if (bytesRead >= LaonProtocol.HEADER_LENGTH) {
                    int totalLength = (int)((MathUtil.convertByteToInt(buffer[14]) << 8) + MathUtil.convertByteToInt(buffer[15])) + LaonProtocol.HEADER_LENGTH;
                    lengthLeft = totalLength - bytesRead;
                    if (bytesRead >= totalLength) {
                        break;
                    }
                } else {
                    lengthLeft = LaonProtocol.HEADER_LENGTH - bytesRead;
                }
            }
        } catch (IOException e) {
            onDisconnected();
            return null;
        }
        
        return Arrays.copyOf(buffer, bytesRead);
    }
    
    protected void sendEvent(Event event) {
        event.setSourceId(mClientId);
        byte[] bytes = event.getBytes();

        try {
            OutputStream outputStream = mSocket.getOutputStream();
            outputStream.write(bytes);
            outputStream.flush();
            Log.out("Event sent     : " + event.toString());
        } catch (IOException e) {
        }
    }
    
    protected void ban() {
        try {
            Log.out(mClientId + " Ban"); // temp
            mSocket.getInputStream().close();
            mSocket.getOutputStream().close();
            mSocket.close();
        } catch (IOException e) {
        }
        mBanTrigger = true;
    }
    
    private void onDisconnected(){
        Log.out("Disconnected");
        ban();
    }
    
    @Override
    public void run() {
        HeartBeatGenerator generator = new HeartBeatGenerator(mClientId, mSocket);
        generator.start();
        
        while (!mBanTrigger) {
            byte[] bytes = receiveEvent();   
            
            if (bytes != null && bytes.length > 0) {
                Event event = new Event();
                event.parse(bytes);
                onEventReceived(event);
            }
        }
        generator.kill();
    }           
        
    public boolean isRegistered() {
        return mIsRegistered;
    }
    
    protected String getClientId() {
        return mClientId;
    }

    protected void onEventReceived(Event event) {
        Log.out("Event received : " + event.toString());
        
        switch(event.getType()) {
            case LaonProtocol.TYPE_CONNECT_ACK:
                onConnectAckEventReceived(event);
                break;
            case LaonProtocol.TYPE_PUBLISH_REQ:
                onPublishReqEventReceived(event);
                break;
            case LaonProtocol.TYPE_PUBLISH_ACK:
                onPublishAckEventReceived(event);
                break;
            case LaonProtocol.TYPE_SUBSCRIBE_ACK:
                onSubscribeAckEventReceived(event);
                break;
            case LaonProtocol.TYPE_UNSUBSCRIBE_ACK:
                onUnsubscribeAckEventReceived(event);
                break;
            case LaonProtocol.TYPE_PING_REQ:
                onPingReqEventReceived(event);
                break;
            case LaonProtocol.TYPE_PING_ACK:
                onPingAckEventReceived(event);
                break;
            case LaonProtocol.TYPE_DISCONNECT_REQ:
                onDisconnectReqEventReceived(event);
                break;
            default:
                onUnknownEventReceived(event);
                break;
       }       
    }

    protected void onConnectAckEventReceived(Event event) {
        mIsRegistered = true;
    }
 
    protected void onPublishReqEventReceived(Event event) {
    }
 
    protected void onPublishAckEventReceived(Event event) {
    }

    protected void onSubscribeAckEventReceived(Event event) {
    }

    protected void onUnsubscribeAckEventReceived(Event event) {
    }

    protected void onPingReqEventReceived(Event event) {
    }
    
    protected void onPingAckEventReceived(Event event) {
    }
   
    protected void onDisconnectReqEventReceived(Event event) {
        ban();
    }
    
    protected void onUnknownEventReceived(Event event) {
        ban();    // unknown means ban!
    }   
}
