package com.middleware.main;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import com.base.protocol.LaonProtocol;
import com.base.util.Log;
import com.middleware.eventbus.EventTunnel;
import com.middleware.eventbus.Oracle;
import com.middleware.eventbus.OracleImpl;


public class Middleware {
    private final static int SERVER_PORT = 550;
    private EventTunnel mTunnel;
    
    public Middleware() {        
    }
    
    public void initialize() {
        mTunnel = new EventTunnel();
        mTunnel.initialize();
        
        try {
            ServerSocket listenerSocket = new ServerSocket(SERVER_PORT);
            Log.out("Waiting for connection on port " + SERVER_PORT + "." );
            while (true) {
                Socket clientSocket = listenerSocket.accept();
                clientSocket.setSoTimeout(LaonProtocol.HEARTBEAT_PERIOD * 2);
                Oracle participant = new OracleImpl(clientSocket, mTunnel);
                participant.launch();
            }
        } catch (IOException e) {
            Log.out("Unable to process client request");
        }
    }
}
