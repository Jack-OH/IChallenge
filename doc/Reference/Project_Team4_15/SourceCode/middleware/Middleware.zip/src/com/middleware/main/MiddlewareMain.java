package com.middleware.main;


public class MiddlewareMain {


    public static void main(String[] args) {
        Middleware middleware = new Middleware();
        middleware.initialize();
    }
}
