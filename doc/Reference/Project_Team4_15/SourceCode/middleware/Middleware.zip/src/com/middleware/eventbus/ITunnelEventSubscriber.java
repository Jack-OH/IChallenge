package com.middleware.eventbus;

import com.base.protocol.Event;


public interface ITunnelEventSubscriber {
    public boolean isSubscribable(String topicAddress, String topicName, String topicCommand);
    public void onTunnelEventReceived(Event event);
}
