package com.middleware.eventbus;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Arrays;

import com.base.protocol.Event;
import com.base.protocol.LaonProtocol;
import com.base.protocol.Topic;
import com.base.util.Log;
import com.base.util.MathUtil;



abstract public class Oracle extends Thread implements ITunnelEventSubscriber {
    private static final int BUFFER_SIZE = 4 * 1024; // 4kb
    private Socket mSocket;
    
    private IEventTunnel mEventTunnel;
    private ArrayList<Topic> mTopicList;

    private boolean mBanTrigger = false;
    
    public Oracle(Socket socket, IEventTunnel tunnel) {
        mSocket = socket;
        mTopicList = new ArrayList<Topic>();
        mEventTunnel = tunnel;
    }

    @Override
    public boolean isSubscribable(String topicAddress, String topicName, String topicCommand) {
        synchronized(mTopicList) {
            for (Topic topic : mTopicList) {
                if (topic.isMatched(topicAddress, topicName, topicCommand)) {
                    return true;
                }
            }            
        }
        return false;
    }
      
    public void launch() {
        start();
    }    

    protected void sendTunnelEvent(Event event) {
        mEventTunnel.sendEvent(event);
    }
    
    @Override
    public void onTunnelEventReceived(Event event) {
        sendEvent(event);
    }
    
    protected void sendEvent(Event event) {
        byte[] bytes = event.getBytes();

        try {
            OutputStream outputStream = mSocket.getOutputStream();
            outputStream.write(bytes);
            outputStream.flush();
            Log.out("Event sent     : " + event.toString());
        } catch (IOException e) {
        }
    }
    
    private byte[] receiveEvent() {
        byte[] buffer = new byte[BUFFER_SIZE];
        int bytesRead = 0;
        int lengthLeft = LaonProtocol.HEADER_LENGTH;
        
        try {
            InputStream inputStream = mSocket.getInputStream();
            while (!mBanTrigger) {
                int length = inputStream.read(buffer, bytesRead, lengthLeft);
                if (length < 0) {                    
                    onDisconnected();
                    break;
                }

                bytesRead += length;

                if (bytesRead >= LaonProtocol.HEADER_LENGTH) {
                    int totalLength = (int)((MathUtil.convertByteToInt(buffer[14]) << 8) + MathUtil.convertByteToInt(buffer[15])) + LaonProtocol.HEADER_LENGTH;
                    lengthLeft = totalLength - bytesRead;
                    if (bytesRead >= totalLength) {
                        break;
                    }
                } else {
                    lengthLeft = LaonProtocol.HEADER_LENGTH - bytesRead;
                }
            }
        } catch (SocketTimeoutException timeoutException) {
            onDisconnected();
            return null;            
        } catch (IOException e) {
            onDisconnected();
            return null;
        }
        
        return Arrays.copyOf(buffer, bytesRead);
    }

    @Override
    public void run() {
        while (!mBanTrigger) {
            byte[] bytes = receiveEvent();
            
            if (bytes != null && bytes.length > 0) {
                Event event = new Event();
                event.parse(bytes);
                onEventReceived(event);
            }
        }
    }        
    
    protected void addTopic(Topic topic) {
        synchronized(mTopicList) {
            mTopicList.add(topic);
        }
    }
  
    protected void removeTopic(Topic topic) {
        synchronized(mTopicList) {
            for (Topic topicItem : mTopicList) {
                if (topicItem.equals(topic)) {
                    mTopicList.remove(topicItem);
                }
            }
        }
    }
    
    protected void participate() {
        mEventTunnel.attachTunnelSubscriber(this);
    }
    
    protected void ban() {
        Log.out("ban");
        mEventTunnel.detachTunnelSubscriber(this);
        
        try {
            mSocket.getInputStream().close();
            mSocket.getOutputStream().close();
            mSocket.close();
        } catch (IOException e) {
        }
        mBanTrigger = true;
    }

    protected void onDisconnected(){
        Log.out("Disconnected");
        ban();
    }
    
    private void onEventReceived(Event event) {
        Log.out("Event received : " + event.toString());
        
        switch(event.getType()) {
            case LaonProtocol.TYPE_CONNECT_REQ:
                onConnectReqEventReceived(event);
                break;
            case LaonProtocol.TYPE_PUBLISH_REQ:
                onPublishReqEventReceived(event);
                break;
            case LaonProtocol.TYPE_SUBSCRIBE_REQ:
                onSubscribeReqEventReceived(event);
                break;
            case LaonProtocol.TYPE_UNSUBSCRIBE_REQ:
                onUnsubscribeReqEventReceived(event);
                break;
            case LaonProtocol.TYPE_PING_REQ:
                onPingReqEventReceived(event);
                break;
            case LaonProtocol.TYPE_DISCONNECT_REQ:
                onDisconnectReqEventReceived(event);
                break;
            default:
                onUnknownEventReceived(event);
                break;
       }       
    }
   
    abstract protected void onUnknownEventReceived(Event event);
    abstract protected void onConnectReqEventReceived(Event event);
    abstract protected void onPublishReqEventReceived(Event event); 
    abstract protected void onSubscribeReqEventReceived(Event event);    
    abstract protected void onUnsubscribeReqEventReceived(Event event);
    abstract protected void onPingReqEventReceived(Event event);
    abstract protected void onDisconnectReqEventReceived(Event event);
}
