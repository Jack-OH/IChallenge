package com.logservice;

import java.util.ArrayList;

import com.base.client.ClientBase;
import com.base.protocol.Event;
import com.base.protocol.LaonProtocol;
import com.base.util.DatabaseManager;
import com.base.util.Log;



public class LogService extends ClientBase {
    private static final ArrayList<String> mNameList = new ArrayList<String>();

    static {
        mNameList.add(LaonProtocol.NAME_DOOR);
        mNameList.add(LaonProtocol.NAME_ALARM);
        mNameList.add(LaonProtocol.NAME_LIGHT);
        mNameList.add(LaonProtocol.NAME_HUMIDITY);
        mNameList.add(LaonProtocol.NAME_TEMPERATURE);
        mNameList.add(LaonProtocol.NAME_PRESENCE);
        mNameList.add(LaonProtocol.NAME_MAILBOX);
//        mNameList.add(LaonProtocol.NAME_EMERGENCY);
    }
    
    public LogService(String clientId) {
        super(clientId);
    }
     
    @Override
    protected void onConnectAckEventReceived(Event event) {
        super.onPublishReqEventReceived(event);
        registerSubscribe();
    }
 
    private void registerSubscribe() {
        for (String name : mNameList) {
            sendRegisterSubscribeEvent(name, LaonProtocol.CONTROL_COMMAND);
            sendRegisterSubscribeEvent(name, LaonProtocol.CURRENT_COMMAND);
        }
    }
    
    private void sendRegisterSubscribeEvent(String name, String command) {
        Event sendEvent = new Event(LaonProtocol.TYPE_SUBSCRIBE_REQ);
        sendEvent.setTopicAddress(LaonProtocol.ASTERISK);
        sendEvent.setTopicName(name);
        sendEvent.setTopicCommand(command);
        sendEvent(sendEvent);
    }
    
    @Override
    protected void onSubscribeAckEventReceived(Event event) {
        super.onSubscribeAckEventReceived(event);
        
        if (LaonProtocol.CONTROL_COMMAND.equals(event.getTopicCommand()) || LaonProtocol.CURRENT_COMMAND.equals(event.getTopicCommand())) {
            storeLogs(event);
        }
    }

    private void storeLogs(Event event) {
        // store logs
        //boolean result = false;
        String[] values = new String[] { Long.toString(System.currentTimeMillis()), event.getSourceId(), event.getTopicAddress() , event.getTopicName() , event.getTopicCommand(), event.getValue() };
        DatabaseManager dm = DatabaseManager.getInstance();
        dm.open();
        dm.insert(DatabaseManager.TABLE_LOG, values);
        dm.close();
        Log.out("Log stored : " + event.toString());
    }
}
