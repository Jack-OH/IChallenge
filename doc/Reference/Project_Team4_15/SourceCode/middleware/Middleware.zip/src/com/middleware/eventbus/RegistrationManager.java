package com.middleware.eventbus;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.base.protocol.LaonProtocol;
import com.base.util.DatabaseManager;

public class RegistrationManager {
    
    private static RegistrationManager mInstance = null;
    
    private RegistrationManager() {
    }
    
    public static RegistrationManager getInstance() {
        if (mInstance == null) {
            mInstance = new RegistrationManager();
            mInstance.initialize();
        }
        return mInstance;
    }
    
    private void initialize() {
        // connect to DBMS
        DatabaseManager.createDb();
    }
    
    public boolean isRegistered(String nodeId) {
        return DatabaseManager.getInstance().isRegistered(nodeId);
    }
    
    public void storeSchema(String nodeId, String schema) {
    	String where = "property=? where name=?";
    	String[] whereArgs = new String[] {schema, nodeId};
    	DatabaseManager dm = DatabaseManager.getInstance();
    	dm.open();
        dm.update(DatabaseManager.TABLE_NODE, where, whereArgs);
    	dm.close();
    }
}
