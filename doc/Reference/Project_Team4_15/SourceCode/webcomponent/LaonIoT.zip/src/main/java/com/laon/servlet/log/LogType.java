package com.laon.servlet.log;

public class LogType {
	private String homeaddr;
	private String timeStamp;
	private String source;
	private String destination;
	private String resource;
	private String command;
	private String value;
	
	public LogType(String homeaddr, String timeStamp, String source, String destination, String resource, String command, String value) {
		this.homeaddr = homeaddr;
		this.timeStamp = timeStamp;
		this.source = source;
		this.destination = destination;
		this.resource = resource;
		this.command = command;
		this.value = value;
	}
	
	public String getHomeaddr() {
		return homeaddr;
	}

	public void setHomeaddr(String homeaddr) {
		this.homeaddr = homeaddr;
	}

	public String getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getResource() {
		return resource;
	}
	public void setResource(String resource) {
		this.resource = resource;
	}
	public String getCommand() {
		return command;
	}
	public void setCommand(String command) {
		this.command = command;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}	
}
