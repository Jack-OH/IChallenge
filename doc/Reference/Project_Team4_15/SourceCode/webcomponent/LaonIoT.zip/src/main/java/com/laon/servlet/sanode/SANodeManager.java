package com.laon.servlet.sanode;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Vector;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;

import com.base.util.DatabaseManager;
import com.laon.servlet.log.LogType;


//@WebServlet("/sanode")
@WebServlet(name = "/sanode", urlPatterns = { "/sanode" })
public class SANodeManager extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		if(req.getParameter("home") != null) {		
			ServletContext sc = this.getServletContext();
			RequestDispatcher rd3 = sc.getRequestDispatcher("/jsp/home/home.jsp");
			rd3.forward(req, resp);
		}
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		if(req.getParameter("addnode") != null) { //Go to registration screen
			goToRegistrationScreen(req, resp);
		} else if(req.getParameter("nodelist") != null) { //SA node list
			goToNodeListScreen(req, resp);
		} else if(req.getParameter("registration") != null) { //Registration a node to DB
			registerNode(req, resp);
		} else if(req.getParameter("removenode") != null) { //Remove nodes
			removeNode(req, resp);			
		} else if(req.getParameter("log") != null || req.getParameter("loguser") != null || req.getParameter("lognode") != null) { //Display log screen
			if(req.getParameter("lognode") != null) {
				goToLogScreen(req, resp, false);
			} else {
				goToLogScreen(req, resp, true);
			}			
		} else if(req.getParameter("control") != null) {
			goToNodeListScreen(req, resp);
		} else { //Go to home screen 
			goToHomeScreen(req, resp);
		}		
	}
	
	private void removeNode(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("Remove SA Node");
		String param = req.getParameter("removenode");
		String[] nodeList = param.split(",");
		//Send node id list to DB manager to remove the nodes
		DatabaseManager dm = DatabaseManager.getInstance();
		for(int i=0; i<nodeList.length; i++) {
			if(dm.deleteNode(nodeList[i]) != 0) {
				
			}
		}
		goToNodeListScreen(req, resp);
	}
	
	private void registerNode(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("Registration a new node");
		String nodeid = req.getParameter("nodeid");
		String pass = req.getParameter("pass");
		if(nodeid != null && pass != null) {
			DatabaseManager db = DatabaseManager.getInstance();
			if(db.isRegisteredNode(nodeid)) {
				System.out.println("Registration a node : SA Node is exist");
				req.getSession().setAttribute("confirmreg", "nodeexist");
			} else {
				//Save new node id and password to DB
				String username = (String)req.getSession().getAttribute("username");
				if(db.registerNode(nodeid, pass, "laon", "team4") == "ok") {
					System.out.println("Registration a node : Ok");
					req.getSession().setAttribute("confirmreg", "ok");
				} else {
					System.out.println("Registration a node : Fail");
					req.getSession().setAttribute("confirmreg", "fail");
				}
			}	
		}
//		req.getSession().removeAttribute("registration");
//		req.getSession().removeAttribute("nodeid");
//		req.getSession().removeAttribute("pass");
		ServletContext sc = this.getServletContext();		
		//RequestDispatcher rd = sc.getRequestDispatcher("/jsp/log/addnode.jsp");
		RequestDispatcher rd = sc.getRequestDispatcher("/jsp/home/home.jsp");
		rd.forward(req, resp);			
		
		req.getSession().removeAttribute("nodeexist");
		req.getSession().removeAttribute("addnode");
	}
	
	private void goToHomeScreen(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		if(req.getParameter("home") != null) {
			System.out.println("Go to home");					
		}
		ServletContext sc = this.getServletContext();
		RequestDispatcher rd = sc.getRequestDispatcher("/jsp/home/home.jsp");
		rd.forward(req, resp);
	}
	
	private void goToNodeListScreen(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("Load SA node list");

		req.getSession().removeAttribute("nodelist");
		req.getSession().removeAttribute("nodeACtrl");
		req.getSession().removeAttribute("nodeBCtrl");
		req.getSession().removeAttribute("nodeCCtrl");
		
		//Get node list from DB
		ArrayList<SANodeType> nodelist = new ArrayList<SANodeType>();

		/*
		int listnum = 3;
		SANodeType sanode = new SANodeType("N-HOUSE001", SANodeType.NODETYPE_A);
		nodelist.add(sanode);
		sanode = new SANodeType("N-MAILBOX1", SANodeType.NODETYPE_B);
		nodelist.add(sanode);
		sanode = new SANodeType("N-HOUSE002", SANodeType.NODETYPE_A);
		nodelist.add(sanode);
		sanode = new SANodeType("N-MAILBOX2", SANodeType.NODETYPE_B);
		nodelist.add(sanode);
		if(listnum == 4) {
			sanode = new SANodeType("N-MAILBOX3", SANodeType.NODETYPE_B);
			nodelist.add(sanode);				
		}
		if(listnum == 5) {
			sanode = new SANodeType("N-HOUSE003", SANodeType.NODETYPE_A);
			nodelist.add(sanode);				
		}
		*/
		
		DatabaseManager db = DatabaseManager.getInstance();		
		try {
			//nodelist = db.getNodeList("laon");
			nodelist = db.getHomeNodeList("team4");
		} catch(SQLException e) {
			e.printStackTrace();
		}
		
		JSONArray jsonArray = new JSONArray();
		for(int i = 0; i<nodelist.size(); i++) {
			jsonArray.add(nodelist.get(i));
		}
		req.getSession().removeAttribute("nodelist");
		req.getSession().setAttribute("nodelist", jsonArray);		
		StringBuilder contentBuilder = new StringBuilder();
		try {				
			BufferedReader in = new BufferedReader(new InputStreamReader(getClass().getResourceAsStream ("typeA.html")));
			String str = null;
			while ((str = in.readLine()) != null) {
		        contentBuilder.append(str);
		    }
		    in.close();
		} catch (IOException e) {
			System.out.println("Error - file read error");
		}
		String nodeACtrl = contentBuilder.toString();
		nodeACtrl = nodeACtrl.replace("\n", "").replace("\r", "").replace("\t", "");
//		System.out.println("nodeA Screen =" +nodeACtrl);
		req.getSession().setAttribute("nodeACtrl", nodeACtrl);
		
		StringBuilder contentBuilder2 = new StringBuilder();
		try {
			BufferedReader in2 = new BufferedReader(new InputStreamReader(getClass().getResourceAsStream ("typeB.html")));
			String str2 = null;
			while ((str2 = in2.readLine()) != null) {
		        contentBuilder2.append(str2);
		    }
		    in2.close();
		} catch (IOException e) {
			System.out.println("Error - file read error");
		}
		String nodeBCtrl = contentBuilder2.toString();
		nodeBCtrl = nodeBCtrl.replace("\n", "").replace("\r", "").replace("\t", "");;
//		System.out.println("nodeB Screen =" +nodeBCtrl);
		req.getSession().setAttribute("nodeBCtrl", nodeBCtrl);
				
		StringBuilder contentBuilder3 = new StringBuilder();
		try {
			BufferedReader in3 = new BufferedReader(new InputStreamReader(getClass().getResourceAsStream ("typeC.html")));
			String str3 = null;
			while ((str3 = in3.readLine()) != null) {
		        contentBuilder3.append(str3);
		    }
		    in3.close();
		} catch (IOException e) {
			System.out.println("Error - file read error");
		}
		String nodeCCtrl = contentBuilder3.toString();
		nodeCCtrl = nodeCCtrl.replace("\n", "").replace("\r", "").replace("\t", "");;
//		System.out.println("nodeB Screen =" +nodeBCtrl);
		req.getSession().setAttribute("nodeCCtrl", nodeCCtrl);
		
/*		resp.setHeader("Cache-Control", "private, no-cache, no-store, must-revalidate, max-age=0, proxy-revalidate, s-maxage=0"); // HTTP 1.1.
		resp.setHeader("Cache-Control", "max-stale=0"); // HTTP 1.1
		resp.setHeader("Pragma", "no-cache"); // HTTP 1.0.
		resp.setHeader("Expires", "0"); //prevents caching at the proxy server
		resp.setDateHeader("Expires", -1); //prevents caching at the proxy server
		resp.setIntHeader("Refresh", 0);
*/
		ServletContext sc = this.getServletContext();
		RequestDispatcher rd = sc.getRequestDispatcher("/jsp/sanode/nodelist.jsp");	
		rd.forward(req, resp);	
	}
	
	private void goToLogScreen(HttpServletRequest req, HttpServletResponse resp, boolean isUserlog) throws ServletException, IOException {
		ArrayList<LogType> userloglist = new ArrayList<LogType>();
		ArrayList<LogType> nodeloglist = new ArrayList<LogType>();
		
		//Get log from to DB
		/*LogType userlogdata = new LogType("Team1", "20150623", "User", "N-HOUSE001", "N-HOUSE001", "door", "open");
		userloglist.add(userlogdata);
		LogType nodelogdata = new LogType("Team1", "20150623", "Node", "N-HOUSE001", "N-HOUSE001", "door", "open");		
		nodeloglist.add(nodelogdata);
		 */
		DatabaseManager db = DatabaseManager.getInstance();		
		try {
			userloglist = db.getLogList("laon");
		} catch(SQLException e) {
			e.printStackTrace();
		}
		JSONArray userLogArray = new JSONArray();
		for(int i = 0; i<userloglist.size(); i++) {
			userLogArray.add(userloglist.get(i));
		}
		/*JSONArray nodeLogArray = new JSONArray();
		for(int i = 0; i<userloglist.size(); i++) {
			nodeLogArray.add(nodeloglist.get(i));
		}*/
		req.getSession().setAttribute("userloglist", userLogArray);
//		req.getSession().removeAttribute("nodeloglist");
//		req.getSession().setAttribute("nodeloglist", nodeLogArray);
		
		ServletContext sc = this.getServletContext();		
		RequestDispatcher logrd = sc.getRequestDispatcher("/jsp/log/log.jsp");
		logrd.forward(req, resp);

		req.getSession().removeAttribute("userloglist");
//		req.getSession().removeAttribute("userloglist");
//		req.getSession().removeAttribute("nodeloglist");
	}
	
	private void goToRegistrationScreen(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("Go to registration a node screen");
		req.getSession().removeAttribute("addnode");

		//Get node list from DB
		ArrayList<SANodeType> nodelist = new ArrayList<SANodeType>();
		DatabaseManager db = DatabaseManager.getInstance();		
		try {
			//nodelist = db.getNodeList("laon");
			nodelist = db.getHomeNodeList("team4");
		} catch(SQLException e) {
			e.printStackTrace();
		}
		
		JSONArray jsonArray = new JSONArray();
		for(int i = 0; i<nodelist.size(); i++) {
			jsonArray.add(nodelist.get(i));
		}
		req.getSession().removeAttribute("nodelist");
		req.getSession().setAttribute("nodelist", jsonArray);		
		
		ServletContext sc = this.getServletContext();
		RequestDispatcher rd = sc.getRequestDispatcher("/jsp/sanode/addnode.jsp");
		rd.forward(req, resp);
	}
}
