package com.laon.servlet.sanode;

public class SANodeType {
	private String nodeid;
	private String door;
	private String alarm;
	private String light;
	private String humidity;
	private String temperature;
	private String presence;
	private String mailbox;
	private String status;
	private String nodeType;
		
	final public static String NODETYPE_A = "nodeA";
	final public static String NODETYPE_B = "nodeB";
	final public static String NODETYPE_C = "nodeC";
	final private String NONE = "NA";
	
	public SANodeType(String nodeid, String nodeType) {
		this.nodeid = nodeid;
		this.nodeType = nodeType;
		if(nodeType == NODETYPE_A) {
			door = "close";
			alarm = "off";
			light = "off";
			humidity = "0";
			temperature = "0";
			presence = "empty";
			mailbox = NONE;
		} else if(nodeType == NODETYPE_B) {
			door = NONE;
			alarm = NONE;
			light = NONE;
			humidity = NONE;
			temperature = NONE;
			presence = NONE;
			mailbox = "empty";
		} else {
			door = NONE;
			alarm = NONE;
			light = NONE;
			humidity = NONE;
			temperature = NONE;
			presence = NONE;
			mailbox = NONE;
		}
		status = "disconnected";
	}
		
	public String getNodeid() {
		return nodeid;
	}

	public void setNodeid(String nodeid) {
		this.nodeid = nodeid;
	}
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getNodeType() {
		return nodeType;
	}

	public void setNodeType(String nodeType) {
		this.nodeType = nodeType;
	}

	public String getDoor() {
		return door;
	}

	public void setDoor(String door) {
		this.door = door;
	}

	public String getAlarm() {
		return alarm;
	}

	public void setAlarm(String alarm) {
		this.alarm = alarm;
	}

	public String getLight() {
		return light;
	}

	public void setLight(String light) {
		this.light = light;
	}

	public String getHumidity() {
		return humidity;
	}

	public void setHumidity(String humidity) {
		this.humidity = humidity;
	}

	public String getTemperature() {
		return temperature;
	}

	public void setTemperature(String temperature) {
		this.temperature = temperature;
	}

	public String getPresence() {
		return presence;
	}
	
	public void setPresence(String presence) {
		this.presence = presence;
	}

	public String getMailbox() {
		return mailbox;
	}

	public void setMailbox(String mailbox) {
		this.mailbox = mailbox;
	}
}
