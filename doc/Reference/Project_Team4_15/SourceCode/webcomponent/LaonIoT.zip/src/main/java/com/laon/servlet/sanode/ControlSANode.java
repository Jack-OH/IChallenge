package com.laon.servlet.sanode;

import com.base.client.ClientBase;
import com.base.protocol.LaonProtocol;
import com.userclient.UserClient;


public class ControlSANode {
	private String doorStatus;
	private String alarmStatus;
	private String lightStatus;
	private String tempStatus;
	private String humidityStatus;
	private String presenceStatus;
	private UserClient userclient;
	private String nodeId; 
	public boolean isLogin;
	
	private ControlSANode() {
		// TODO Auto-generated constructor stub
		doorStatus = "close";
		alarmStatus = "off";
		lightStatus = "off";
		tempStatus = "70";
		humidityStatus = "50";
		presenceStatus = "empty";
		nodeId = "N-HOUSE001";
		try {
			userclient = new UserClient("S-TOMCAT01");
		} catch(Exception e) {
			System.out.println("User client error");
		}
	}
	
	private static ControlSANode instance;
	
	public static ControlSANode getInstance() {
		if(instance == null) {
			instance = new ControlSANode();
		}
		
		return instance;
	}
	
	public UserClient getUserclient() {
		return userclient;
	}

	public Boolean removeNode(Integer nodeid) {
		Boolean retval = true;
		
		return retval;
	}
	
	public String getDoorStatus() { return this.doorStatus; }

	public String getAlarmStatus() { return this.alarmStatus; }
	
	public String getLightStatus() { return this.lightStatus; }
	
	public String getTemparatureStatus() { return this.tempStatus; }
	
	public String getHumidityStatus() { return this.humidityStatus; }
	
	public String getPresenceStatus() { return this.presenceStatus; }
		
	public String getNodeId() {
		return nodeId;
	}

	public void setNodeId(String nodeId) {
		this.nodeId = nodeId;
	}

	public void openDoor() {
		System.out.println(nodeId + " Control.door.open");
		this.doorStatus = LaonProtocol.VALUE_OPEN;
		try {
			userclient.sendControlEvent(nodeId, LaonProtocol.NAME_DOOR, LaonProtocol.VALUE_OPEN);
		} catch(Exception e) {
			System.out.println("[Error] Open door error");
		}
	}
	
	public void closeDoor() {
		System.out.println(nodeId + " Control.door.close");
		this.doorStatus = LaonProtocol.VALUE_CLOSE;
		try {
			userclient.sendControlEvent(nodeId, LaonProtocol.NAME_DOOR, LaonProtocol.VALUE_CLOSE);
		} catch(Exception e) {
			System.out.println("[Error] Close door error");
		}
	}
	
	public void onLight() {
		System.out.println(nodeId + " Control.light.on");	
		this.lightStatus = LaonProtocol.VALUE_ON;
		try {
			userclient.sendControlEvent(nodeId, LaonProtocol.NAME_LIGHT, LaonProtocol.VALUE_ON);
		} catch(Exception e) {
			System.out.println("[Error] On light error");
		}
	}
	
	public void offLight() {
		System.out.println(nodeId + " Control.light.off");
		lightStatus = LaonProtocol.VALUE_OFF;
		try {
			userclient.sendControlEvent(nodeId, LaonProtocol.NAME_LIGHT, LaonProtocol.VALUE_OFF);
		} catch(Exception e) {
			System.out.println("[Error] Off light error");
		}
	}
	
	public void onAlarm() {
		System.out.println(nodeId + " Control.alram.on");	
		alarmStatus = LaonProtocol.VALUE_ON;
		try {
			userclient.sendControlEvent(nodeId, LaonProtocol.NAME_ALARM, LaonProtocol.VALUE_ON);
		} catch(Exception e) {
			System.out.println("[Error] On alarm error");
		}
	}
	
	public void offAlarm() {
		System.out.println(nodeId + " Control.alarm.off");
		alarmStatus = LaonProtocol.VALUE_OFF;
		try {
			userclient.sendControlEvent(nodeId, LaonProtocol.NAME_ALARM, LaonProtocol.VALUE_OFF);
		} catch(Exception e) {
			System.out.println("[Error] Off alarm error");
		}
	}
}
