package com.laon.servlet.sanode;

import java.io.IOException;
import java.util.Vector;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class SANodeController
 */
@WebServlet(name = "/controller", urlPatterns = { "/controller" })
public class SANodeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SANodeController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("SA Node Controller");
		
		String attr = request.getParameter("control");
		String attrs[] = attr.split("_", 2);
		ControlSANode control = ControlSANode.getInstance();
		control.setNodeId(attrs[1]);
		if(attrs[0].equals("dooropen")) {
			control.openDoor();
		} else if(attrs[0].equals("doorclose")) {
			control.closeDoor();
		} else if(attrs[0].equals("lighton")) {
			control.onLight();
		} else if(attrs[0].equals("lightoff")) {
			control.offLight();
		} else if(attrs[0].equals("alarmon")) {
			control.onAlarm();
		} else if(attrs[0].equals("alarmoff")) {
			control.offAlarm();
		}

//		request.getSession().setAttribute("control", "controlonly");
		//request.getSession().removeAttribute("control");
		response.sendRedirect("/jsp/sanode/nodelist.jsp");		
	}
}
