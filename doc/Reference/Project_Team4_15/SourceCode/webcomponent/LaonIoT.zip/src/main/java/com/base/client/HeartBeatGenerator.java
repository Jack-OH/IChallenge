package com.base.client;

import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;

import com.base.protocol.Event;
import com.base.protocol.LaonProtocol;
import com.base.util.Log;



public class HeartBeatGenerator extends Thread {
    private Socket mSocket;
    private boolean mBanTrigger = false;
    private String mClientId = "          ";
   
    public HeartBeatGenerator(String clientId, Socket socket) {
        mClientId = clientId;
        mSocket = socket;
    }
    
    public void launch() {
        start();
    } 
    
    @Override
    synchronized public void run() {
        while (!mBanTrigger) {
            try {
                wait(LaonProtocol.HEARTBEAT_PERIOD);
            } catch (InterruptedException e) {
            }
            sendHeartBeat();
        }
    }           

    private void sendHeartBeat() {
        Event event = new Event(LaonProtocol.TYPE_PING_REQ, mClientId);
        byte[] bytes = event.getBytes();

        try {
            OutputStream outputStream = mSocket.getOutputStream();
            outputStream.write(bytes);
            outputStream.flush();
//            Log.out("Event sent     : " + event.toString());
        } catch (IOException e) {
            stop();
        }
    }
    
    public void kill() {
        mBanTrigger = true;
    }
}
