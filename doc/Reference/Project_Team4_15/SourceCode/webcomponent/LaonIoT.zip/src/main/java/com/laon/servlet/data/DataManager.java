package com.laon.servlet.data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.sqlite.SQLiteConfig;

public class DataManager {
	private Connection connection;
	public boolean isOpened = false;
	
	private static final String DATABASE_NAME = "laondata.db";
	
	private DataManager() {
		// TODO Auto-generated constructor stub
		try {
			Class.forName("org.sqlite.JDBC");
		} catch(Exception e) { e.printStackTrace(); }
	}
	
	private static DataManager instance;
	
	public static DataManager getInstance() {
		if(instance == null) {
			instance = new DataManager();
		}
		
		return instance;
	}
	
//	static {
//		try {
//			Class.forName("org.sqlite.JDBC");
//		} catch(Exception e) { e.printStackTrace(); }
//	}
	
	
	public boolean open() {
		try {
			// �б� ����
			SQLiteConfig config = new SQLiteConfig();
			config.setReadOnly(true);
			this.connection = DriverManager.getConnection("jdbc:sqlite:D:\\LaonIoT\\bin\\data\\laondata.db", config.toProperties());
		} catch(SQLException e) { 
			e.printStackTrace();
			return false; 
		}

		isOpened = true;
		return true;
	}


	public boolean close() {
		if(this.isOpened == false) {
			return true; 
		}

		try {
			this.connection.close();
		} catch(SQLException e) { 
			e.printStackTrace();
			return false; 
		}
		return true;
	}
	
	
		
}
