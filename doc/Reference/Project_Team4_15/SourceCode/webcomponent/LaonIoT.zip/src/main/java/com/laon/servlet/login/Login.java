package com.laon.servlet.login;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.base.client.ClientBase;
import com.base.util.DatabaseManager;
import com.laon.servlet.sanode.ControlSANode;


@WebServlet("/home")
public class Login extends HttpServlet {
	public Login() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
//		super.doGet(req, resp);
		
	}
	
	private synchronized void InitializeUserClient() {
		System.out.println("Initialize user client");
		//Registration user client to service
		ControlSANode control = ControlSANode.getInstance();
		if(control.isLogin) return;
//		String DEFAULT_SERVER_IP = "192.168.1.129";
		String DEFAULT_SERVER_IP = "192.168.1.118";
		ClientBase client = control.getUserclient();
        if (client.initialize(DEFAULT_SERVER_IP)) {
            System.out.println("User client initialization");
        	client.launch();
        }
        boolean isRegistered = true;
		while(!client.isRegistered()) {
        	try {
				wait(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				isRegistered = false;
			}
        }
		if(isRegistered) control.isLogin = true;
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String username = req.getParameter("username");
		String password = req.getParameter("pass");
		
		ServletContext sc = this.getServletContext();
		if(req.getParameter("logout") != null) {
			System.out.println("Logout");
			req.getSession().invalidate();
			//resp.sendRedirect("/index.jsp");			
			RequestDispatcher rd3 = sc.getRequestDispatcher("/index.jsp");
			rd3.forward(req, resp);
			return;
		} 
		
		InitializeUserClient();	        			
		//Get user information from DB
		DatabaseManager db = DatabaseManager.getInstance();
		//Check user id & password
		if(db.isRegisteredUser(username, password)) {
//		if(username.equals("laon") && password.equals("0000")) {
			System.out.println("User Login completed");
			req.getSession().setAttribute("username", username);
	        RequestDispatcher rd = sc.getRequestDispatcher("/jsp/home/home.jsp");
			rd.forward(req, resp);						
		} else {
			System.out.println("Wrong ID or password");
			RequestDispatcher rd2 = sc.getRequestDispatcher("/jsp/home/unauthorized.jsp");
			rd2.forward(req, resp);
		}
	}
}
