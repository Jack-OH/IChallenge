package lecture.patterns.ocp;

public class Rectangle {
	public void draw() {
		System.out.println("Draw Rectangle~!");
	}
}
