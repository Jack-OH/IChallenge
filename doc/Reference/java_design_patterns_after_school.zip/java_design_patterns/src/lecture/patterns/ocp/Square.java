package lecture.patterns.ocp;

public class Square {
	public void draw() {
		System.out.println("Draw Square~!");
	}
}
