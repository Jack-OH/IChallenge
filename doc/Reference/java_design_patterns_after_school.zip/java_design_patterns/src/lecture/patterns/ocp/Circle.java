package lecture.patterns.ocp;

public class Circle {
	public void draw() {
		System.out.println("Draw Circle~!");
	}
}
