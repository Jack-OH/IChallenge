package lecture.patterns.abstractfactory.framework;

public abstract class Square {
	public abstract void draw();
}
