package lecture.patterns.prototype.graphiceditor;
import lecture.patterns.prototype.framework.grahpic.*;

public class Square extends Shape{
	public void draw() {
		System.out.println("Draw Square");
	}
}
