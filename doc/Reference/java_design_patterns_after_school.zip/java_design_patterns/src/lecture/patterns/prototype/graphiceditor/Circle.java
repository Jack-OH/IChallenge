package lecture.patterns.prototype.graphiceditor;
import lecture.patterns.prototype.framework.grahpic.*;

public class Circle extends Shape{
	public void draw() {
		System.out.println("Draw Circle");
	}
}
