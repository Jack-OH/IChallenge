package lecture.patterns.observer2;

import java.util.Observable;

public class IncrementalNumberGenerator extends Observable {
    
	private int number;
	private int end;
	private int inc;
	
	public IncrementalNumberGenerator(int start, int end, int inc) {
		this.number = start;
		this.end = end;
		this.inc = inc;
	}
	
	public int getNumber() {
		return number;
	}
	
	public void execute() {
		for(int i=this.number;i<this.end;i+=this.inc) {
			this.number = i;
			setChanged();
			notifyObservers(number);
		}	
	}
}
