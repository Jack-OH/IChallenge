package lecture.patterns.observer2;

import java.util.Observable;
import java.util.Observer;

public class GraphObserver implements Observer {

	public void update(Observable o, Object arg) {
		System.out.print("GraphObserver: ");
		
		for(int i=0;i<(int)arg;i++)
			System.out.print("*");
		
		System.out.println();
		
		
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
		}
	}
    
}
