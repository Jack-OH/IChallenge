package lecture.patterns.templatemethod;

public class Tea extends Beverage{
    
	public void brew(){
		System.out.println("Steeping the tea");
	}
	
	public void addCondiments(){
		System.out.println("Adding Lemon");
	}
}
