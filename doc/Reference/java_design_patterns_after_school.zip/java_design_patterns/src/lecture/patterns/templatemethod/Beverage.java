package lecture.patterns.templatemethod;

public abstract class Beverage {
	
    final void prepareRecipe() {	// 재정의 불가하도록 해야함.
    	boilWater();
    	brew();
        pourInCup();
		addCondiments(); 
	}
 
	abstract void brew();
  
	abstract void addCondiments();
 
	void boilWater() {
		System.out.println("Boiling water");
	}
  
	void pourInCup() {
		System.out.println("Pouring into cup");
	}
	
}

    