/*
* Copyright LG Electronics (c) 2014
* All rights reserved.
* M Task Team <A-MTask@lge.com>
*
*/

package com.android.mms.notification;

public class MessageNotificationFactory {

	public static final int MESSAGE_NOTIFCATION_ID = 100;
	public static final int CLASSZERO_NOTIFICATION = 200;
	public static final int MESSAGE_SEND_FAIL_NOTIFICATION_ID = 300;
	public static final int MESSAGE_RECEIVE_FAIL_NOTIFICATION_ID = 310;
	public static final int SIM_MESSAGE_NOTIFCATION_ID_SIM1 = 321;
	public static final int SIM_MESSAGE_NOTIFCATION_ID_SIM2 = 322;
	public static final int SIM_MESSAGE_NOTIFCATION_ID_SIM3 = 323;
	public static final int SIM_MESSAGE_NOTIFCATION_ID_SIM4 = 324;
	public static final int CMAS_NOTIFICATION_ID = 400;
	
	private int mNotificationId;
	
	public MessageNotificationFactory(final int notificationId) {
		mNotificationId = notificationId;
	}
	
	public MessageNotification getInstance() {
		return (new MessageNotification(mNotificationId));
	}


}//end MessageNotificationFactory