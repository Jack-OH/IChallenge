/*
* Copyright LG Electronics (c) 2014
* All rights reserved.
* M Task Team <A-MTask@lge.com>
*
*/
package com.android.mms.notification;

import android.net.Uri;


public class SoundPlayer {

	public SoundPlayer() {

	}

	public int play() {
		return 0;
	}

	public int setSound(Uri soundUri) {
		return 0;
	}

	public int stop() {
		return 0;
	}
}//end soundPlayer