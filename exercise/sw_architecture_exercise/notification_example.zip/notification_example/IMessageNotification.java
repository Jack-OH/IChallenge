/*
* Copyright LG Electronics (c) 2014
* All rights reserved.
* M Task Team <A-MTask@lge.com>
*
*/
package com.android.mms.notification;


public interface IMessageNotification {

	/**
	 * 
	 * @param notificationId    notificationId
	 */
	public abstract int cancel(long notificationId);

	/**
	 * 
	 * @param notificationId
	 * @param msgTheadId
	 * @param subscriptionId    subscriptionId
	 */
	public abstract int notify(long notificationId, long TheadId, int subscriptionId);

}