/*
* Copyright LG Electronics (c) 2014
* All rights reserved.
* M Task Team <A-MTask@lge.com>
*
*/
package com.android.mms.notification;


public class LockScreenDistributor {

	public LockScreenDistributor() {

	}

}//end lockScreenDistributor