/*
* Copyright LG Electronics (c) 2014
* All rights reserved.
* M Task Team <A-MTask@lge.com>
*
*/
package com.android.mms.notification;


public class MessageNotification implements IMessageNotification {

	public MessageNotification() {

	}

	/**
	 * 
	 * @param threadId    threadId
	 */
	public MessageNotification(long threadId) {

	}

	/**
	 * 
	 * @param notificationId    notificationId
	 */
	public int cancel(long notificationId) {
		return 0;
	}

	/**
	 * 
	 * @param notificationId
	 * @param msgTheadId
	 * @param subscriptionId    subscriptionId
	 */
	public int notify(long notificationId, long msgTheadId, int subscriptionId) {
		NotificationUpdater notificationUpdater = new NotificationUpdater();
		return (notificationUpdater.commit()); 
	}
}//end MessageNotification