/*
* Copyright LG Electronics (c) 2014
* All rights reserved.
* M Task Team <A-MTask@lge.com>
*
*/
package com.android.mms.notification;


public class TickerMaker {

	private StringBuilder mTicker;
	
	public TickerMaker() {
		mTicker = new StringBuilder();
		mTicker.setLength(0);
	}
	
	public String make() {
		return mTicker.toString();
	}

}//end tickerMaker