/*
* Copyright LG Electronics (c) 2014
* All rights reserved.
* M Task Team <A-MTask@lge.com>
*
*/
package com.android.mms.notification;


public class NotificationTypeChecker {
	
	private boolean mStatus;

	public NotificationTypeChecker() {

	}


	public boolean getType() {
		return mStatus;
	}
}//end notificationTypeChecker