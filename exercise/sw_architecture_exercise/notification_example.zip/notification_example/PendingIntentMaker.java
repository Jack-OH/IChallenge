/*
* Copyright LG Electronics (c) 2014
* All rights reserved.
* M Task Team <A-MTask@lge.com>
*
*/
package com.android.mms.notification;

import android.content.Intent;


public class PendingIntentMaker {

	private Intent mPendingIntent;
	public PendingIntentMaker() {
		mPendingIntent = new Intent();
	}
	
	public Intent makePendeingIntent(int threadId) {
		return mPendingIntent;
	}
}//end pendingIntentMaker