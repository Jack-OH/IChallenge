/*
* Copyright LG Electronics (c) 2014
* All rights reserved.
* M Task Team <A-MTask@lge.com>
*
*/
package com.android.mms.notification;


public class ScreenChecker {

	public enum ScreenStatus { SCREENOFF, SCREENON };
	
	private ScreenStatus mStatus = ScreenStatus.SCREENOFF;

	public ScreenChecker() {

	}

	public ScreenStatus getStatus() {
		return mStatus;
	}
}//end screenChecker